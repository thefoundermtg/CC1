# Harmony Ledger

Harmony Ledger is an AI-assisted, ledger-secured music split sheet and royalty distribution MVP. It helps creators create split proposals, review warnings, collect authenticated e-signatures, lock agreements to a tamper-evident ledger, import royalty statements, and queue equitable distributions.

## What is implemented

- FastAPI backend with SQLAlchemy models
- Next.js frontend with production build passing
- Auth with password hashing, login lockout, refresh-token storage, email verification tokens, password reset tokens, and HTTP-only cookie support
- Public signup restricted to Creator accounts; privileged roles require invites/platform approval
- Project/collaborator CRUD with richer music metadata
- AI-assisted split generator with warnings and editable human override workflow
- Agreement template generation with versioning language and legal disclaimers
- Secure signer invite flow: unique tokens, view/sign/decline events, IP/user-agent capture, consent text, signature hash, audit trail
- PDF export and signature certificate export
- Tamper-evident permissioned ledger with canonical payload JSON and recomputable block hashes
- Royalty manual/CSV import, ownership validation, distribution queue, batch creation, mock payout processing
- Stripe-ready billing endpoints and plan limits scaffold
- Request IDs, security headers, basic rate limiting, health/ready/version endpoints
- Alembic migration scaffold and GitHub CI

## Run locally

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python scripts/init_db.py
uvicorn app.main:app --reload
```

```bash
cd frontend
npm ci
cp .env.example .env.local
npm run dev
```

Backend: `http://localhost:8000/api/health`
Frontend: `http://localhost:3000`

## Production notes

Run Alembic migrations before the API starts. Do not use `AUTO_CREATE_TABLES=true` in production. Configure Postgres, Redis/background workers, object storage, email delivery, Stripe Billing, payout provider, monitoring, backups, and attorney-approved legal pages before launch.

The current ledger is a tamper-evident internal permissioned hash chain. To accurately market as a multi-node permissioned blockchain, integrate a true blockchain layer such as Hyperledger Fabric, Quorum, or FireFly.
