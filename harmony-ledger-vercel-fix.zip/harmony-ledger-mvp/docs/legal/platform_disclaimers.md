# Legal pages to finalize before launch

Add attorney-reviewed pages for:

- Terms of Use
- Privacy Policy
- Cookie Notice
- E-Sign Consent
- Split Sheet and AI Assistance Disclaimer
- Royalty Distribution and Payout Disclaimer
- No Legal Advice Disclaimer
- DMCA Policy
- Data Retention, Export, and Deletion Policy
- Dispute/Correction Process

The product copy should avoid saying AI determines ownership. Use: "AI assists drafting and review; collaborators make the final agreement."
