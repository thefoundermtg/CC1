# Product Requirements Document

## Customer
Professional music creators, producers, songwriters, artists, publishers, labels, and management teams who collaborate often and need clean IP split records.

## Core jobs to be done
1. Create a reliable split sheet quickly after a studio session.
2. Capture collaborator identity and music-industry metadata before confusion starts.
3. Make every party sign the same version.
4. Lock a tamper-evident record.
5. Import royalty earnings and show who should receive what.

## MVP features
- Account creation and login.
- Project/work creation.
- Collaborator data capture: legal name, email, creative role, PRO, IPI/CAE, publisher, payout reference.
- AI-assisted split generation with confidence score.
- Manual split override with 100% validation.
- Split-sheet agreement generation.
- Electronic signature record.
- Ledger lock and verification.
- Manual royalty import and distribution queue.
- Dashboard for catalog status.

## Non-MVP / later
- Real PRO integrations.
- Distributor integrations.
- Stripe Connect payouts.
- Team seat management.
- Contract template library by territory and rights type.
- Invite links and verified collaborator onboarding.
- Full permissioned blockchain nodes for enterprise accounts.
- Dispute resolution workflow.
