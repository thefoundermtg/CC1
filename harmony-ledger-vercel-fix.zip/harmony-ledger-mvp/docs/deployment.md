# Deployment Instructions

## Local Docker
```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env.local
./scripts/dev.sh
```

Frontend: `http://localhost:3000`  
Backend health: `http://localhost:8000/api/health`  
API docs: `http://localhost:8000/docs`

## Local without Docker
Backend:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Frontend:
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

## Production target
- Frontend: Vercel, Cloudflare Pages, or containerized Next.js.
- Backend: Render, Fly.io, DigitalOcean App Platform, AWS ECS, or Kubernetes.
- Database: managed Postgres.
- Ledger: start with internal hash chain; upgrade to Hyperledger Fabric/Quorum adapter for enterprise customers.
- Jobs: add Celery/RQ/Sidekiq-style worker for royalty imports, emails, and ledger anchoring.
