# Database Schema

Core entities:

- `users`: account, role, PRO, IPI/CAE, payout reference.
- `organizations`: publisher/label/team account shell for later multi-seat plans.
- `projects`: song/work metadata, owner, ISWC/ISRC, status.
- `collaborators`: project-specific collaborator identity and payment metadata.
- `split_proposals`: AI-generated or manually adjusted split drafts.
- `split_participants`: per-collaborator percentages and contribution notes.
- `agreements`: generated split-sheet agreement text, hash, status, ledger block.
- `signatures`: signer consent and signature hash.
- `ledger_blocks`: append-only permissioned ledger hash chain.
- `royalty_imports`: statement/import header.
- `royalty_line_items`: income by work.
- `royalty_distributions`: calculated recipient amounts and payout status.
- `audit_logs`: operational traceability.

Important constraints:

- `collaborators` has unique `(project_id, email)`.
- `split_participants.percentage` is constrained to 0–100.
- API-level validation enforces proposal totals = 100%.
- Distributions can only be created when a project has a locked agreement.
