# Harmony Ledger System Architecture

## MVP principle
Build the narrowest production-shaped workflow that proves the business: create a work, capture collaborators, generate a proposed split, create an agreement, collect signatures, lock a tamper-evident record, import royalties, and queue distributions.

## Logical architecture
```mermaid
flowchart LR
  U[Creator / Publisher / Label Admin] --> FE[Next.js Web App]
  FE --> API[FastAPI REST API]
  API --> AUTH[JWT Auth + RBAC]
  API --> DB[(Postgres)]
  API --> AI[Split AI Service]
  API --> LEDGER[Permissioned Ledger Adapter]
  API --> ROYALTY[Royalty Import Adapters]
  LEDGER --> DB
  ROYALTY --> DB
  DB --> AUDIT[Audit Logs]
```

## Production architecture
```mermaid
flowchart TB
  subgraph Client
    Web[Next.js frontend]
  end
  subgraph API Layer
    Gateway[API Gateway / WAF]
    FastAPI[FastAPI app]
    Worker[Background worker]
  end
  subgraph Data
    Postgres[(Postgres)]
    ObjectStore[(S3-compatible object storage)]
    Redis[(Redis queue/cache)]
  end
  subgraph Integrations
    LLM[LLM split drafting]
    Ledger[Hyperledger/Quorum permissioned ledger]
    Payments[Stripe Connect / payment provider]
    PROs[ASCAP/BMI/SESAC/MLC/SoundExchange adapters]
    Email[Transactional email]
  end
  Web --> Gateway --> FastAPI
  FastAPI --> Postgres
  FastAPI --> Redis --> Worker
  Worker --> LLM
  Worker --> Ledger
  Worker --> Payments
  Worker --> PROs
  Worker --> Email
  Worker --> ObjectStore
```

## Why the MVP uses an internal ledger first
The MVP includes a database-backed hash chain. Every locked agreement stores a canonical payload hash, previous block hash, block index, and block hash. This is tamper-evident today and keeps the service boundary clean for a later external permissioned blockchain integration.

## Trust boundaries
- Frontend never decides splits, signatures, or ledger state.
- API validates ownership and percentages.
- Agreements cannot be edited after being locked.
- Royalty distributions require a locked agreement.
- The ledger is append-only at the application layer.
