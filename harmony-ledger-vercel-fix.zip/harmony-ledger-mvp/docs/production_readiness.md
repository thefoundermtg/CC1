# Harmony Ledger production readiness implementation notes

This build upgrades the original scaffold into a production-oriented MVP foundation. The implementation includes secure account flows, invite-based e-signatures, agreement versioning, audit events, ledger verification, royalty import/reconciliation primitives, billing scaffolding, CI, and migration infrastructure.

## Important remaining external integrations

The code now has boundaries for these systems, but production launch still requires real provider credentials, legal review, and operational setup:

- Email provider: replace `NotificationService` logging with SES, Postmark, SendGrid, or Mailgun.
- Billing: replace mock Stripe-ready checkout/portal responses with real Stripe Billing sessions and verified webhook handling.
- Payouts: replace mock payout processing with Stripe Connect, Moov, or another compliant payout provider with KYC/tax flows.
- AI: add a real LLM adapter behind `SplitAIService` while keeping human approval and deterministic validation.
- Blockchain: current ledger is a recomputable tamper-evident permissioned hash chain. For a true multi-node permissioned blockchain, implement a Fabric/Quorum/FireFly adapter and optionally anchor block hashes externally.
- Object storage: store immutable PDFs, royalty statements, and signature certificates in S3-compatible storage.
- Legal: attorney-approved Terms, Privacy Policy, E-Sign Consent, Split Sheet Disclaimer, payout disclosures, and data-retention/delete/export policies are required before public launch.

## Migration policy

Production must not create tables from app startup. Run:

```bash
cd backend
alembic upgrade head
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

For local demos only, set `AUTO_CREATE_TABLES=true` or run `python scripts/init_db.py`.
