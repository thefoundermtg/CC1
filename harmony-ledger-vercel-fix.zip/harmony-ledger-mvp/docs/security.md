# Security checklist

Implemented:

- Creator-only public signup; privileged roles require invite/approval.
- Password length validation and secure hashing boundary with Argon2-capable implementation.
- Refresh token table with rotation support.
- HTTP-only cookie support plus bearer fallback for development.
- Login lockout after repeated failures.
- Email verification and password-reset token tables.
- Request IDs, security headers, CORS allowlist, and basic rate limiting.
- Signed agreement invite tokens are stored only as hashes.
- Signatures capture signer name, email, consent text, timestamp, agreement hash, signature hash, IP, and user agent.
- Owner-entered signatures are disabled.
- Ledger blocks store canonical payload JSON and recomputable hashes.
- Royalty imports verify project ownership before distributions are created.
- Alembic migrations replace production startup schema creation.

Before launch:

- Set a strong `JWT_SECRET` from a secret manager.
- Use HTTPS only and set `SECURE_COOKIE=true`.
- Add MFA for publisher/label/platform admin accounts.
- Move PDFs/uploads to private object storage with short-lived signed URLs.
- Add Sentry/structured logging with PII scrubbing.
- Add WAF/DDoS protection and production-grade rate limits.
- Add dependency scanning and secret scanning in CI.
- Add database backups and point-in-time recovery.
- Verify Stripe webhooks with the Stripe signature secret.
- Complete penetration testing before handling real royalties or payouts.
