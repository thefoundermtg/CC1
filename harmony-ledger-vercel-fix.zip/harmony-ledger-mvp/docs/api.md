# API summary

Base URL: `/api`

## Health
- `GET /health`
- `GET /ready`
- `GET /version`

## Auth
- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/refresh`
- `POST /auth/logout`
- `POST /auth/verify-email`
- `POST /auth/request-email-verification`
- `POST /auth/password-reset/request`
- `POST /auth/password-reset/confirm`
- `GET /auth/me`

## Projects
- `POST /projects`
- `GET /projects?status=&q=&limit=&offset=`
- `GET /projects/{project_id}`
- `PATCH /projects/{project_id}`
- `DELETE /projects/{project_id}`
- `POST /projects/{project_id}/archive`
- `POST /projects/{project_id}/collaborators`
- `PATCH /projects/{project_id}/collaborators/{collaborator_id}`
- `DELETE /projects/{project_id}/collaborators/{collaborator_id}`
- `POST /projects/{project_id}/invite-collaborators`

## Splits
- `POST /projects/{project_id}/splits/analyze`
- `POST /projects/{project_id}/splits/generate`
- `GET /projects/{project_id}/splits`
- `PUT /projects/{project_id}/splits/{proposal_id}`
- `POST /projects/{project_id}/splits/{proposal_id}/request-changes`
- `POST /projects/{project_id}/splits/{proposal_id}/approve`
- `POST /projects/{project_id}/splits/{proposal_id}/finalize`

## Agreements
- `POST /agreements`
- `GET /agreements`
- `GET /agreements/{agreement_id}`
- `POST /agreements/{agreement_id}/send-signature-requests`
- `GET /agreements/{agreement_id}/signature-certificate`
- `GET /agreements/{agreement_id}/signature-certificate.pdf`
- `GET /agreements/{agreement_id}/pdf`
- `POST /agreements/{agreement_id}/lock`
- `GET /agreements/{agreement_id}/ledger-proof`
- `GET /agreements/{agreement_id}/verify`

Unsafe owner-entered signing is intentionally disabled at `POST /agreements/{agreement_id}/sign`.

## Public signing
- `GET /signing/invites/{token}`
- `POST /signing/invites/{token}/sign`
- `POST /signing/invites/{token}/decline`

## Ledger
- `GET /ledger/blocks`
- `GET /ledger/blocks/{block_id}`
- `GET /ledger/verify`

## Royalties
- `POST /royalties/imports`
- `POST /royalties/imports/csv`
- `POST /royalties/imports/{import_id}/reconcile`
- `GET /royalties/imports`
- `GET /royalties/distributions`
- `POST /royalties/distribution-batches`
- `POST /royalties/distribution-batches/{batch_id}/approve`
- `GET /royalties/payouts`
- `POST /royalties/payouts`

## Billing
- `GET /billing/subscription`
- `GET /billing/limits`
- `POST /billing/checkout`
- `POST /billing/portal`
- `POST /billing/webhooks/stripe`

## Dashboard
- `GET /dashboard`
