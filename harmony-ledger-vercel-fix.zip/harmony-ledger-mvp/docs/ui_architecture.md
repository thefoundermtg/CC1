# UI Architecture

## Screens

## Public landing
Purpose: explain the problem, solution, product workflow, and pricing.

Primary CTA: Create your first split sheet.

## Register / login
Purpose: authenticate creators, publishers, and label admins.

Fields: legal name, email, password, account type, PRO, IPI/CAE.

## Dashboard
Purpose: show operating status of catalog and money workflows.

Cards:
- Active projects
- Locked agreements
- Queued royalties
- Recent projects table

## New project
Purpose: capture the work and collaborator metadata before any split is drafted.

Fields:
- Work title, release date, ISWC, ISRC
- Collaborator legal name, email, creative role, PRO, IPI/CAE

## Project detail
Purpose: manage one work through the full split lifecycle.

Sections:
- Work metadata
- Collaborator table
- AI-assisted contribution notes
- Latest proposal review
- Create agreement action

## Agreements
Purpose: review generated agreement, record signatures, lock to ledger, and verify.

Actions:
- Record signature
- Lock to ledger
- Verify ledger record

## Royalties
Purpose: import income for a work and queue distributions using the locked split.

Actions:
- Manual statement import
- Distribution queue review

## UX rules
- Never let a project distribute royalties until it has a locked agreement.
- Always show collaborator legal identity, PRO, and IPI/CAE near split percentages.
- Treat AI as an assistant, not the final decision-maker.
- Show confidence score and require human review.
- After lock, show hash, block id, and verification status.
