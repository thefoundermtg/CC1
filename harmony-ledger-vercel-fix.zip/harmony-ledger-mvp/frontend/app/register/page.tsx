'use client';
import { FormEvent, useState } from 'react';
import Link from 'next/link';
import { apiFetch } from '@/lib/api';

export default function RegisterPage() {
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    const form = new FormData(event.currentTarget);
    try {
      await apiFetch('/auth/register', {
        method: 'POST',
        body: JSON.stringify({
          full_name: form.get('full_name'),
          email: form.get('email'),
          password: form.get('password'),
          account_type: 'creator',
          pro_affiliation: form.get('pro_affiliation') || null,
          ipi_cae_number: form.get('ipi_cae_number') || null,
          accept_terms: Boolean(form.get('accept_terms'))
        })
      });
      setMessage('Account created. Check your email/logs for the verification link, then log in.');
    } catch (err) { setError(err instanceof Error ? err.message : 'Registration failed'); }
  }
  return (
    <main className="container section">
      <div className="card" style={{ maxWidth: 620, margin: '40px auto' }}>
        <h2>Create account</h2>
        <form className="form" onSubmit={onSubmit}>
          {message && <div className="success">{message} <Link href="/login">Log in</Link></div>}
          {error && <div className="error">{error}</div>}
          <label className="label">Full legal name<input className="input" name="full_name" required /></label>
          <label className="label">Email<input className="input" name="email" type="email" required /></label>
          <label className="label">Password<input className="input" name="password" type="password" minLength={10} maxLength={128} required /></label>
          <div className="notice">Publisher, label, and admin access is invite/approval-only. Public signup creates a Creator account.</div>
          <label className="label">PRO affiliation<input className="input" name="pro_affiliation" placeholder="ASCAP, BMI, SESAC, etc." /></label>
          <label className="label">IPI/CAE number<input className="input" name="ipi_cae_number" /></label>
          <label className="check"><input name="accept_terms" type="checkbox" required /> I accept the Terms, Privacy Policy, E-Sign Consent, and Split Sheet Disclaimer.</label>
          <button className="btn primary" type="submit">Create account</button>
        </form>
      </div>
    </main>
  );
}
