'use client';
import { useEffect, useMemo, useState } from 'react';
import { apiFetch } from '@/lib/api';
export default function VerifyEmailPage() {
  const token = useMemo(() => typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('token') || '' : '', []);
  const [message, setMessage] = useState('Verifying...');
  useEffect(() => { if (!token) { setMessage('Missing token.'); return; } apiFetch('/auth/verify-email', { method: 'POST', body: JSON.stringify({ token }) }).then(() => setMessage('Email verified. You can log in.')).catch((err) => setMessage(err instanceof Error ? err.message : 'Verification failed')); }, [token]);
  return <main className="container section"><div className="card" style={{maxWidth:520,margin:'40px auto'}}><h2>Email verification</h2><p>{message}</p></div></main>;
}
