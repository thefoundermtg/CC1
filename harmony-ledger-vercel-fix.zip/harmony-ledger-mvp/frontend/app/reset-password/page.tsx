'use client';
import { FormEvent, useMemo, useState } from 'react';
import { apiFetch } from '@/lib/api';
export default function ResetPasswordPage() {
  const token = useMemo(() => typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('token') || '' : '', []);
  const [message, setMessage] = useState(''); const [error, setError] = useState('');
  async function submit(e: FormEvent<HTMLFormElement>) { e.preventDefault(); const f = new FormData(e.currentTarget); try { await apiFetch('/auth/password-reset/confirm', { method: 'POST', body: JSON.stringify({ token: f.get('token'), new_password: f.get('password') }) }); setMessage('Password updated. You can log in now.'); } catch (err) { setError(err instanceof Error ? err.message : 'Reset failed'); } }
  return <main className="container section"><form className="card form" onSubmit={submit} style={{maxWidth:520,margin:'40px auto'}}><h2>Choose new password</h2>{message&&<div className="success">{message}</div>}{error&&<div className="error">{error}</div>}<label className="label">Token<input className="input" name="token" defaultValue={token} required /></label><label className="label">New password<input className="input" type="password" name="password" minLength={10} required /></label><button className="btn primary">Update password</button></form></main>;
}
