'use client';
import { useEffect, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch } from '@/lib/api';
import type { Agreement, SigningInvite } from '@/lib/types';

export default function AgreementsPage() {
  const [agreements, setAgreements] = useState<Agreement[]>([]);
  const [selected, setSelected] = useState<Agreement | null>(null);
  const [invites, setInvites] = useState<SigningInvite[]>([]);
  const [proof, setProof] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  useEffect(() => { refresh(); }, []);
  async function refresh() { try { const data = await apiFetch<Agreement[]>('/agreements'); setAgreements(data); if (!selected && data[0]) setSelected(data[0]); } catch (err) { setError(err instanceof Error ? err.message : 'Could not load agreements'); } }
  async function sendRequests(id: string) { setError(''); setMessage(''); try { const created = await apiFetch<SigningInvite[]>(`/agreements/${id}/send-signature-requests`, { method: 'POST' }); setInvites(created); setMessage('Signature requests generated. In production these are emailed; local mode returns/logs links.'); await refresh(); } catch (err) { setError(err instanceof Error ? err.message : 'Could not send requests'); } }
  async function lock(id: string) { setError(''); setMessage(''); try { await apiFetch(`/agreements/${id}/lock`, { method: 'POST' }); setMessage('Agreement locked to ledger.'); await refresh(); } catch (err) { setError(err instanceof Error ? err.message : 'Could not lock agreement'); } }
  async function verify(id: string) { setError(''); setMessage(''); try { const result = await apiFetch<Record<string, unknown>>(`/agreements/${id}/verify`); setProof(JSON.stringify(result, null, 2)); } catch (err) { setError(err instanceof Error ? err.message : 'Could not verify'); } }
  async function certificate(id: string) { setError(''); try { const result = await apiFetch<Record<string, unknown>>(`/agreements/${id}/signature-certificate`); setProof(JSON.stringify(result, null, 2)); } catch (err) { setError(err instanceof Error ? err.message : 'Could not load certificate'); } }
  return (
    <AuthGuard>
      <main className="container section stack">
        <div><div className="eyebrow">Signatures + ledger</div><h2>Agreements</h2></div>
        {error && <div className="error">{error}</div>}{message && <div className="success">{message}</div>}
        <section className="grid two">
          <div className="card stack"><h3>Agreement list</h3><table className="table"><thead><tr><th>Version</th><th>Status</th><th>Hash</th><th></th></tr></thead><tbody>{agreements.map((agreement) => <tr key={agreement.id}><td>v{agreement.version}</td><td><span className="badge">{agreement.status}</span></td><td>{agreement.agreement_hash?.slice(0, 10) || 'Pending'}</td><td><button className="btn" onClick={() => { setSelected(agreement); setProof(''); setInvites([]); }}>Open</button></td></tr>)}</tbody></table></div>
          <div className="card stack"><h3>{selected ? `Agreement v${selected.version}` : 'Select an agreement'}</h3>{selected && <><pre style={{ whiteSpace: 'pre-wrap', color: 'var(--muted)', maxHeight: 320, overflow: 'auto' }}>{selected.legal_text}</pre><div className="row"><button className="btn primary" onClick={() => sendRequests(selected.id)}>Send signature requests</button><button className="btn" onClick={() => lock(selected.id)}>Lock to ledger</button><button className="btn" onClick={() => verify(selected.id)}>Verify</button><button className="btn" onClick={() => certificate(selected.id)}>Certificate</button><a className="btn" href={`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000/api'}/agreements/${selected.id}/pdf`} target="_blank">PDF</a></div></>}</div>
        </section>
        {invites.length > 0 && <section className="card stack"><h3>Signing links</h3>{invites.map(invite => <div className="notice" key={invite.id}><strong>{invite.email}</strong> · {invite.status}<br />{invite.invite_url}</div>)}</section>}
        {proof && <section className="card stack"><h3>Verification / certificate output</h3><pre style={{ whiteSpace: 'pre-wrap', color: 'var(--muted)', maxHeight: 380, overflow: 'auto' }}>{proof}</pre></section>}
      </main>
    </AuthGuard>
  );
}
