'use client';
import { FormEvent, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch } from '@/lib/api';

type DraftCollaborator = { legal_name: string; email: string; creative_role: string; split_category: string; pro_affiliation: string; ipi_cae_number: string; publisher_name: string; payout_reference: string; is_work_for_hire: boolean; sample_disclosure: string };
const blank = (): DraftCollaborator => ({ legal_name:'', email:'', creative_role:'writer', split_category:'composition', pro_affiliation:'', ipi_cae_number:'', publisher_name:'', payout_reference:'', is_work_for_hire:false, sample_disclosure:'' });

export default function NewProjectPage() {
  const [error, setError] = useState('');
  const [collaborators, setCollaborators] = useState<DraftCollaborator[]>([blank()]);
  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError('');
    const form = new FormData(event.currentTarget);
    const cleaned = collaborators.filter(c => c.legal_name && c.email).map(c => ({ ...c, pro_affiliation: c.pro_affiliation || null, ipi_cae_number: c.ipi_cae_number || null, publisher_name: c.publisher_name || null, payout_reference: c.payout_reference || null, sample_disclosure: c.sample_disclosure || null }));
    try {
      const project = await apiFetch<{ id: string }>('/projects', { method: 'POST', body: JSON.stringify({ title: form.get('title'), work_type: form.get('work_type'), alternate_titles: form.get('alternate_titles') || null, iswc: form.get('iswc') || null, isrc: form.get('isrc') || null, release_date: form.get('release_date') || null, collaborators: cleaned }) });
      window.location.href = `/projects/${project.id}`;
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not create project'); }
  }
  function update(index: number, patch: Partial<DraftCollaborator>) { setCollaborators(collaborators.map((c,i)=>i===index?{...c,...patch}:c)); }
  return (
    <AuthGuard>
      <main className="container section">
        <div className="card stack">
          <div><div className="eyebrow">Step 1</div><h2>Create a work</h2><p>Add song metadata and every collaborator that should appear on the split sheet.</p></div>
          <form className="form" onSubmit={onSubmit}>
            {error && <div className="error">{error}</div>}
            <div className="grid two">
              <label className="label">Song / work title<input className="input" name="title" required /></label>
              <label className="label">Work type<select className="input" name="work_type"><option value="song">Song</option><option value="master_recording">Master Recording</option><option value="composition">Composition</option></select></label>
              <label className="label">Alternate titles<input className="input" name="alternate_titles" /></label>
              <label className="label">Release date<input className="input" name="release_date" type="date" /></label>
              <label className="label">ISWC<input className="input" name="iswc" /></label>
              <label className="label">ISRC<input className="input" name="isrc" /></label>
            </div>
            <div className="row" style={{justifyContent:'space-between'}}><h3>Collaborators</h3><button className="btn" type="button" onClick={()=>setCollaborators([...collaborators, blank()])}>Add collaborator</button></div>
            {collaborators.map((c, index) => (
              <div className="card stack" key={index}>
                <div className="row" style={{justifyContent:'space-between'}}><strong>Collaborator {index+1}</strong>{collaborators.length > 1 && <button className="btn danger" type="button" onClick={()=>setCollaborators(collaborators.filter((_,i)=>i!==index))}>Remove</button>}</div>
                <div className="grid two">
                  <label className="label">Legal name<input className="input" value={c.legal_name} onChange={e=>update(index,{legal_name:e.target.value})} required={index===0} /></label>
                  <label className="label">Email<input className="input" type="email" value={c.email} onChange={e=>update(index,{email:e.target.value})} required={index===0} /></label>
                  <label className="label">Creative role<select className="input" value={c.creative_role} onChange={e=>update(index,{creative_role:e.target.value})}><option value="writer">Writer</option><option value="producer">Producer</option><option value="artist">Artist</option><option value="publisher">Publisher</option><option value="engineer">Engineer</option></select></label>
                  <label className="label">Split category<select className="input" value={c.split_category} onChange={e=>update(index,{split_category:e.target.value})}><option value="composition">Composition / writer share</option><option value="publishing">Publishing share</option><option value="master">Master ownership</option><option value="producer_points">Producer points</option><option value="neighboring_rights">Neighboring rights</option></select></label>
                  <label className="label">PRO<input className="input" value={c.pro_affiliation} onChange={e=>update(index,{pro_affiliation:e.target.value})} placeholder="ASCAP, BMI, SESAC..." /></label>
                  <label className="label">IPI/CAE<input className="input" value={c.ipi_cae_number} onChange={e=>update(index,{ipi_cae_number:e.target.value})} /></label>
                  <label className="label">Publisher<input className="input" value={c.publisher_name} onChange={e=>update(index,{publisher_name:e.target.value})} /></label>
                  <label className="label">Payout reference<input className="input" value={c.payout_reference} onChange={e=>update(index,{payout_reference:e.target.value})} /></label>
                </div>
                <label className="check"><input type="checkbox" checked={c.is_work_for_hire} onChange={e=>update(index,{is_work_for_hire:e.target.checked})} /> Work-for-hire or separate contract applies</label>
                <label className="label">Sample/interpolation disclosure<textarea value={c.sample_disclosure} onChange={e=>update(index,{sample_disclosure:e.target.value})} /></label>
              </div>
            ))}
            <button className="btn primary" type="submit">Create project</button>
          </form>
        </div>
      </main>
    </AuthGuard>
  );
}
