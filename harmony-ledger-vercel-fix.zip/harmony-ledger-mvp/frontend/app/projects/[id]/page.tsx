'use client';
import { FormEvent, useEffect, useMemo, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch, parseWarnings } from '@/lib/api';
import type { Agreement, Project, SplitProposal } from '@/lib/types';

type EditableParticipant = { collaborator_id: string; split_category: string; contribution_type: string; contribution_notes: string; percentage: string };

export default function ProjectDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const [projectId, setProjectId] = useState('');
  const [project, setProject] = useState<Project | null>(null);
  const [splits, setSplits] = useState<SplitProposal[]>([]);
  const [agreement, setAgreement] = useState<Agreement | null>(null);
  const [edits, setEdits] = useState<EditableParticipant[]>([]);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  useEffect(() => { params.then((p) => setProjectId(p.id)); }, [params]);
  useEffect(() => { if (projectId) refresh(); }, [projectId]);

  async function refresh() {
    try {
      const [projectData, splitData] = await Promise.all([apiFetch<Project>(`/projects/${projectId}`), apiFetch<SplitProposal[]>(`/projects/${projectId}/splits`)]);
      setProject(projectData); setSplits(splitData);
      if (splitData[0]) setEdits(splitData[0].participants.map(p => ({ collaborator_id:p.collaborator_id, split_category:p.split_category, contribution_type:p.contribution_type, contribution_notes:p.contribution_notes, percentage:String(p.percentage) })));
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not load project'); }
  }

  async function generateSplit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setMessage('');
    const form = new FormData(event.currentTarget);
    const participant_inputs: Record<string, string> = {};
    project?.collaborators.forEach((collab) => participant_inputs[collab.id] = form.get(`notes_${collab.id}`)?.toString() || '');
    try {
      await apiFetch(`/projects/${projectId}/splits/generate`, { method: 'POST', body: JSON.stringify({ input_notes: form.get('input_notes'), participant_inputs }) });
      setMessage('AI-assisted split generated. Review warnings and edit percentages before creating an agreement.'); await refresh();
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not generate split'); }
  }

  async function saveOverrides(proposalId: string) {
    setError(''); setMessage('');
    try { await apiFetch(`/projects/${projectId}/splits/${proposalId}`, { method:'PUT', body: JSON.stringify({ participants: edits.map(e => ({...e, percentage: Number(e.percentage)})) }) }); setMessage('Split overrides saved.'); await refresh(); } catch (err) { setError(err instanceof Error ? err.message : 'Could not save overrides'); }
  }
  async function approve(proposalId: string) { try { await apiFetch(`/projects/${projectId}/splits/${proposalId}/approve`, { method:'POST' }); setMessage('Split approved.'); await refresh(); } catch (err) { setError(err instanceof Error ? err.message : 'Could not approve split'); } }
  async function createAgreement(proposalId: string) { setError(''); setMessage(''); try { const created = await apiFetch<Agreement>('/agreements', { method: 'POST', body: JSON.stringify({ proposal_id: proposalId }) }); setAgreement(created); setMessage('Agreement created. Go to Agreements to send signature requests.'); await refresh(); } catch (err) { setError(err instanceof Error ? err.message : 'Could not create agreement'); } }

  const latest = splits[0];
  const totals = useMemo(() => edits.reduce<Record<string, number>>((acc, item) => { acc[item.split_category] = (acc[item.split_category] || 0) + Number(item.percentage || 0); return acc; }, {}), [edits]);
  if (!project) return <AuthGuard><main className="container section"><div className="card">Loading project...</div></main></AuthGuard>;
  const warnings = parseWarnings(latest?.warnings_json);
  return (
    <AuthGuard>
      <main className="container section stack">
        {error && <div className="error">{error}</div>}{message && <div className="success">{message}</div>}
        <section className="card stack">
          <div className="eyebrow">Project</div><h2>{project.title}</h2>
          <p>Status: <span className="badge">{project.status}</span> · ISWC: {project.iswc || 'Pending'} · ISRC: {project.isrc || 'Pending'}</p>
          <table className="table"><thead><tr><th>Collaborator</th><th>Role</th><th>Category</th><th>PRO</th><th>IPI/CAE</th></tr></thead><tbody>
            {project.collaborators.map((c) => <tr key={c.id}><td>{c.legal_name}<br /><span className="muted">{c.email}</span></td><td>{c.creative_role}</td><td>{c.split_category}</td><td>{c.pro_affiliation || '—'}</td><td>{c.ipi_cae_number || '—'}</td></tr>)}
          </tbody></table>
        </section>
        <section className="card stack">
          <div><div className="eyebrow">Step 2</div><h2>Generate split sheet proposal</h2></div>
          <form className="form" onSubmit={generateSplit}>
            <label className="label">Session summary<textarea name="input_notes" placeholder="Who wrote lyrics, melody, beat, hook, verses, production, arrangement, samples, work-for-hire terms, etc.?" required /></label>
            {project.collaborators.map((collab) => <label className="label" key={collab.id}>{collab.legal_name} contribution notes<textarea name={`notes_${collab.id}`} /></label>)}
            <button className="btn primary" type="submit">Generate AI-assisted split</button>
          </form>
        </section>
        {latest && <section className="card stack">
          <div><div className="eyebrow">Latest proposal</div><h2>Review and edit percentages</h2><p>{latest.ai_summary} Confidence: {latest.confidence_score}% · Status: <span className="badge">{latest.status}</span></p></div>
          {warnings.length > 0 && <div className="stack">{warnings.map((w, idx) => <div className={w.severity === 'high' ? 'error' : 'notice'} key={idx}><strong>{w.severity.toUpperCase()}:</strong> {w.message}</div>)}</div>}
          <div className="notice">Totals: {Object.entries(totals).map(([k,v]) => `${k}: ${v.toFixed(2)}%`).join(' · ')}</div>
          <table className="table"><thead><tr><th>Name</th><th>Category</th><th>Contribution</th><th>Split %</th></tr></thead><tbody>
            {edits.map((p, idx) => { const collab = project.collaborators.find(c => c.id === p.collaborator_id); return <tr key={`${p.collaborator_id}-${idx}`}><td>{collab?.legal_name}</td><td><input className="input" value={p.split_category} onChange={e=>setEdits(edits.map((x,i)=>i===idx?{...x,split_category:e.target.value}:x))} /></td><td><input className="input" value={p.contribution_notes} onChange={e=>setEdits(edits.map((x,i)=>i===idx?{...x,contribution_notes:e.target.value}:x))} /></td><td><input className="input" type="number" step="0.01" min="0" max="100" value={p.percentage} onChange={e=>setEdits(edits.map((x,i)=>i===idx?{...x,percentage:e.target.value}:x))} /></td></tr>; })}
          </tbody></table>
          <div className="row"><button className="btn" onClick={() => saveOverrides(latest.id)}>Save overrides</button><button className="btn" onClick={() => approve(latest.id)}>Approve split</button><button className="btn primary" onClick={() => createAgreement(latest.id)}>Create signature agreement</button></div>
        </section>}
        {agreement && <section className="card stack"><div><div className="eyebrow">Agreement created</div><h2>Agreement #{agreement.version}</h2></div><pre style={{ whiteSpace: 'pre-wrap', color: 'var(--muted)' }}>{agreement.legal_text}</pre></section>}
      </main>
    </AuthGuard>
  );
}
