'use client';
import { useEffect, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch } from '@/lib/api';
import type { User } from '@/lib/types';
export default function AccountPage() {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => { apiFetch<User>('/auth/me').then(setUser); }, []);
  return <AuthGuard><main className="container section stack"><div><div className="eyebrow">Account</div><h2>Security and profile</h2></div><section className="card stack"><p><strong>Name:</strong> {user?.full_name}</p><p><strong>Email:</strong> {user?.email}</p><p><strong>Role:</strong> {user?.role}</p><p><strong>Email verified:</strong> {user?.email_verified_at ? 'Yes' : 'No'}</p><p className="muted">Production accounts use server-set HTTP-only cookies, refresh tokens, account lockout, and invite-only privileged roles.</p></section></main></AuthGuard>;
}
