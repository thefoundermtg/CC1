'use client';
import { FormEvent, useEffect, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch } from '@/lib/api';
import type { Distribution, Payout, Project, RoyaltyImport } from '@/lib/types';

export default function RoyaltiesPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [imports, setImports] = useState<RoyaltyImport[]>([]);
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  useEffect(() => { refresh(); }, []);
  async function refresh() {
    try { const [p, i, d, pay] = await Promise.all([apiFetch<Project[]>('/projects'), apiFetch<RoyaltyImport[]>('/royalties/imports'), apiFetch<Distribution[]>('/royalties/distributions'), apiFetch<Payout[]>('/royalties/payouts')]); setProjects(p); setImports(i); setDistributions(d); setPayouts(pay); } catch (err) { setError(err instanceof Error ? err.message : 'Could not load royalties'); }
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setMessage(''); const form = new FormData(event.currentTarget);
    try { await apiFetch('/royalties/imports', { method: 'POST', body: JSON.stringify({ source: form.get('source'), period_start: form.get('period_start'), period_end: form.get('period_end'), currency: 'USD', idempotency_key: form.get('idempotency_key') || null, line_items: [{ project_id: form.get('project_id'), description: form.get('description'), gross_amount: Number(form.get('gross_amount')), currency: 'USD' }] }) }); setMessage('Royalty import processed and distributions queued.'); await refresh(); } catch (err) { setError(err instanceof Error ? err.message : 'Could not process royalty import'); }
  }
  async function createBatch() { try { await apiFetch('/royalties/distribution-batches', { method:'POST' }); setMessage('Distribution batch created.'); await refresh(); } catch(err) { setError(err instanceof Error ? err.message : 'Could not create batch'); } }
  async function processPayouts() { try { const res = await apiFetch<{paid:number}>('/royalties/payouts', { method:'POST' }); setMessage(`Processed ${res.paid} mock payouts.`); await refresh(); } catch(err) { setError(err instanceof Error ? err.message : 'Could not process payouts'); } }
  return (
    <AuthGuard>
      <main className="container section stack">
        <div><div className="eyebrow">Royalty tracking</div><h2>Imports, reconciliation, distribution queue, and payouts</h2><p>Manual/CSV import is the MVP adapter; PRO/distributor integrations can plug into this same reconciliation pipeline.</p></div>
        {error && <div className="error">{error}</div>}{message && <div className="success">{message}</div>}
        <section className="grid two">
          <form className="card form" onSubmit={submit}>
            <h3>Manual royalty import</h3>
            <label className="label">Source<input className="input" name="source" defaultValue="Manual" /></label>
            <label className="label">Project<select className="input" name="project_id" required>{projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}</select></label>
            <label className="label">Period start<input className="input" name="period_start" type="date" required /></label>
            <label className="label">Period end<input className="input" name="period_end" type="date" required /></label>
            <label className="label">Description<input className="input" name="description" defaultValue="Streaming royalty statement" /></label>
            <label className="label">Gross amount<input className="input" name="gross_amount" type="number" min="0" step="0.01" required /></label>
            <label className="label">Idempotency key<input className="input" name="idempotency_key" placeholder="Optional duplicate protection key" /></label>
            <button className="btn primary" type="submit">Queue distributions</button>
          </form>
          <div className="card stack"><h3>Accounting actions</h3><button className="btn" onClick={createBatch}>Create distribution batch</button><button className="btn primary" onClick={processPayouts}>Process mock payouts</button><div className="notice">Real payouts should be connected to Stripe Connect/Moov with KYC, tax, failed-payout, and minimum-payout rules before launch.</div></div>
        </section>
        <section className="card stack"><h3>Import history</h3><table className="table"><thead><tr><th>Source</th><th>Period</th><th>Total</th><th>Status</th></tr></thead><tbody>{imports.map(i => <tr key={i.id}><td>{i.source}</td><td>{i.period_start} → {i.period_end}</td><td>{i.currency} {i.total_amount}</td><td><span className="badge">{i.status}</span></td></tr>)}</tbody></table></section>
        <section className="card stack"><h3>Distribution queue</h3><table className="table"><thead><tr><th>Collaborator ID</th><th>Split</th><th>Amount</th><th>Status</th></tr></thead><tbody>{distributions.map((d) => <tr key={d.id}><td>{d.collaborator_id.slice(0, 8)}...</td><td>{d.percentage}%</td><td>{d.currency} {d.amount}</td><td><span className="badge">{d.payout_status}</span></td></tr>)}</tbody></table></section>
        <section className="card stack"><h3>Payouts</h3><table className="table"><thead><tr><th>Collaborator ID</th><th>Amount</th><th>Provider</th><th>Status</th></tr></thead><tbody>{payouts.map((p) => <tr key={p.id}><td>{p.collaborator_id.slice(0,8)}...</td><td>{p.currency} {p.amount}</td><td>{p.provider}</td><td><span className="badge">{p.status}</span></td></tr>)}</tbody></table></section>
      </main>
    </AuthGuard>
  );
}
