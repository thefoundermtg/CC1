'use client';
import Link from 'next/link';
import { FormEvent, useState } from 'react';
import { apiFetch, setToken } from '@/lib/api';

export default function LoginPage() {
  const [error, setError] = useState('');
  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    const form = new FormData(event.currentTarget);
    try {
      const result = await apiFetch<{ access_token: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: form.get('email'), password: form.get('password') })
      });
      setToken(result.access_token);
      window.location.href = '/dashboard';
    } catch (err) { setError(err instanceof Error ? err.message : 'Login failed'); }
  }
  return (
    <main className="container section">
      <div className="card" style={{ maxWidth: 520, margin: '40px auto' }}>
        <h2>Log in</h2>
        <form className="form" onSubmit={onSubmit}>
          {error && <div className="error">{error}</div>}
          <label className="label">Email<input className="input" name="email" type="email" required /></label>
          <label className="label">Password<input className="input" name="password" type="password" required /></label>
          <button className="btn primary" type="submit">Log in</button>
          <Link className="muted" href="/forgot-password">Forgot password?</Link>
        </form>
      </div>
    </main>
  );
}
