'use client';
import { FormEvent, useState } from 'react';
import { apiFetch } from '@/lib/api';
export default function ForgotPasswordPage() {
  const [message, setMessage] = useState(''); const [error, setError] = useState('');
  async function submit(e: FormEvent<HTMLFormElement>) { e.preventDefault(); setError(''); const f = new FormData(e.currentTarget); try { await apiFetch('/auth/password-reset/request', { method: 'POST', body: JSON.stringify({ email: f.get('email') }) }); setMessage('If that email exists, a reset link has been sent/logged.'); } catch (err) { setError(err instanceof Error ? err.message : 'Request failed'); } }
  return <main className="container section"><form className="card form" onSubmit={submit} style={{maxWidth:520,margin:'40px auto'}}><h2>Reset password</h2>{message&&<div className="success">{message}</div>}{error&&<div className="error">{error}</div>}<label className="label">Email<input className="input" type="email" name="email" required /></label><button className="btn primary">Send reset link</button></form></main>;
}
