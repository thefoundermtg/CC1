'use client';
import { useEffect, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch } from '@/lib/api';
type Subscription = { plan_code: string; status: string; current_period_end?: string | null };
export default function BillingPage() {
  const [subscription, setSubscription] = useState<Subscription | null>(null); const [message, setMessage] = useState(''); const [error, setError] = useState('');
  useEffect(() => { apiFetch<Subscription>('/billing/subscription').then(setSubscription).catch((err) => setError(err instanceof Error ? err.message : 'Could not load billing')); }, []);
  async function checkout(plan_code: string) { setError(''); try { const res = await apiFetch<{url:string;mode:string}>('/billing/checkout', { method:'POST', body: JSON.stringify({ plan_code }) }); setMessage(`Billing ${res.mode}: ${res.url}`); const fresh = await apiFetch<Subscription>('/billing/subscription'); setSubscription(fresh); } catch(err) { setError(err instanceof Error ? err.message : 'Checkout failed'); } }
  return <AuthGuard><main className="container section stack"><div><div className="eyebrow">Billing</div><h2>Plans and limits</h2><p>Stripe-ready billing endpoints are scaffolded; without Stripe keys the app runs in mock billing mode.</p></div>{error&&<div className="error">{error}</div>}{message&&<div className="success">{message}</div>}<section className="card"><p>Current plan: <span className="badge">{subscription?.plan_code || 'loading'}</span> · {subscription?.status}</p></section><section className="grid"><div className="card stack"><h3>Free Trial</h3><div className="stat">$0</div><button className="btn" onClick={()=>checkout('free_trial')}>Select</button></div><div className="card stack"><h3>Pro Creator</h3><div className="stat">$49/mo</div><button className="btn primary" onClick={()=>checkout('pro_creator_49')}>Upgrade</button></div><div className="card stack"><h3>Publisher / Label</h3><div className="stat">$199/mo</div><button className="btn primary" onClick={()=>checkout('publisher_label_199')}>Upgrade</button></div></section></main></AuthGuard>;
}
