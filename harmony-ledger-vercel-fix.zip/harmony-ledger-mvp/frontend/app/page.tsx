import Link from 'next/link';

export default function HomePage() {
  return (
    <main>
      <section className="container hero">
        <div>
          <div className="eyebrow">Music IP splits, finally clean</div>
          <h1>AI-assisted split sheets secured by a permissioned ledger.</h1>
          <p>
            Harmony Ledger helps songwriters, producers, artists, publishers, and labels create transparent split sheets,
            collect signatures, lock tamper-evident agreement records, and track royalty distributions from one workflow.
          </p>
          <div className="row" style={{ marginTop: 24 }}>
            <Link className="btn primary" href="/register">Create your first split sheet</Link>
            <Link className="btn" href="/login">Log in</Link>
          </div>
        </div>
        <div className="card stack">
          <div className="badge">Production MVP flow</div>
          <h2>From studio session to royalty queue.</h2>
          <div className="grid" style={{ gridTemplateColumns: '1fr', gap: 12 }}>
            <div className="card"><strong>1. Add collaborators</strong><p>Capture legal name, email, PRO, IPI/CAE, publisher, role, and payout reference.</p></div>
            <div className="card"><strong>2. Generate AI split</strong><p>Use transparent contribution scoring, then manually approve or override percentages.</p></div>
            <div className="card"><strong>3. Sign and lock</strong><p>Create agreement text, collect signatures, hash the payload, and write a ledger block.</p></div>
          </div>
        </div>
      </section>
      <section className="container section grid">
        <div className="card"><h3>Pro Creator</h3><div className="stat">$49/mo</div><p>Solo creators and frequent collaborators who need clean splits and earnings visibility.</p></div>
        <div className="card"><h3>Publisher / Label</h3><div className="stat">$199/mo</div><p>Teams managing multiple catalogs, creators, agreements, and royalty imports.</p></div>
        <div className="card"><h3>Enterprise</h3><div className="stat">Custom</div><p>Advanced ledger nodes, integrations, permissions, and catalog administration workflows.</p></div>
      </section>
    </main>
  );
}
