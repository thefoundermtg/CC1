'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import AuthGuard from '@/components/AuthGuard';
import { apiFetch } from '@/lib/api';
import type { Dashboard, Project } from '@/lib/types';

export default function DashboardPage() {
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([apiFetch<Dashboard>('/dashboard'), apiFetch<Project[]>('/projects')])
      .then(([dash, projectList]) => { setDashboard(dash); setProjects(projectList); })
      .catch((err) => setError(err instanceof Error ? err.message : 'Could not load dashboard'));
  }, []);

  return (
    <AuthGuard>
      <main className="container section stack">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div><div className="eyebrow">Catalog command center</div><h2>Dashboard</h2></div>
          <Link className="btn primary" href="/projects/new">New project</Link>
        </div>
        {error && <div className="error">{error}. Please log in again.</div>}
        <section className="grid">
          <div className="card"><span className="muted">Active projects</span><div className="stat">{dashboard?.active_projects ?? '—'}</div></div>
          <div className="card"><span className="muted">Pending signatures</span><div className="stat">{dashboard?.pending_signatures ?? '—'}</div></div>
          <div className="card"><span className="muted">Queued royalties</span><div className="stat">${dashboard?.queued_royalties ?? '0.00'}</div></div>
          <div className="card"><span className="muted">Split warnings</span><div className="stat">{dashboard?.splits_with_warnings ?? '—'}</div></div>
          <div className="card"><span className="muted">Ledger blocks</span><div className="stat">{dashboard?.ledger_blocks ?? '—'}</div></div>
          <div className="card"><span className="muted">Subscription</span><div className="stat" style={{fontSize:24}}>{dashboard?.subscription_status ?? '—'}</div></div>
        </section>
        <section className="card">
          <h3>Recent projects</h3>
          <table className="table"><thead><tr><th>Title</th><th>Status</th><th>Collaborators</th><th></th></tr></thead><tbody>
            {projects.map((project) => <tr key={project.id}><td>{project.title}</td><td><span className="badge">{project.status}</span></td><td>{project.collaborators.length}</td><td><Link href={`/projects/${project.id}`}>Open</Link></td></tr>)}
          </tbody></table>
        </section>
        <section className="card stack"><h3>Recent audit events</h3>{dashboard?.recent_events?.map((event, idx) => <div key={idx} className="notice"><strong>{event.action}</strong> · {event.entity_type} · {new Date(event.created_at).toLocaleString()}</div>)}</section>
      </main>
    </AuthGuard>
  );
}
