'use client';
import { ReactNode, useEffect, useState } from 'react';
import { apiFetch } from '@/lib/api';
import type { User } from '@/lib/types';

export default function AuthGuard({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    apiFetch<User>('/auth/me')
      .then(() => setReady(true))
      .catch(() => { window.location.href = '/login'; });
  }, []);
  if (!ready) return <main className="container section"><div className="card">Checking your session...</div></main>;
  return <>{children}</>;
}
