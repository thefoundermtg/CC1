'use client';
import Link from 'next/link';
import { clearToken, getToken, apiFetch } from '@/lib/api';
import { useEffect, useState } from 'react';

export default function Nav() {
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => setSignedIn(Boolean(getToken())), []);
  async function signOut() { try { await apiFetch('/auth/logout', { method:'POST' }); } catch {} clearToken(); window.location.href = '/'; }
  return (
    <header className="container nav">
      <Link href="/" className="brand"><span className="mark">HL</span><span>Harmony Ledger</span></Link>
      <nav className="navlinks">
        <Link href="/dashboard">Dashboard</Link><Link href="/projects/new">New Project</Link><Link href="/agreements">Agreements</Link><Link href="/royalties">Royalties</Link><Link href="/billing">Billing</Link><Link href="/account">Account</Link>
        {signedIn ? <button className="btn" onClick={signOut}>Sign out</button> : <><Link href="/login">Log in</Link><Link href="/register" className="btn primary">Start free</Link></>}
      </nav>
    </header>
  );
}
