const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000/api';

export function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem('harmony_token');
}

export function setToken(token: string) {
  window.localStorage.setItem('harmony_token', token);
}

export function clearToken() {
  window.localStorage.removeItem('harmony_token');
}

export async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const suppliedHeaders = (options.headers || {}) as Record<string, string>;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...suppliedHeaders
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body instanceof FormData) {
    delete headers['Content-Type'];
  }

  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers, cache: 'no-store', credentials: 'include' });
  if (!response.ok) {
    let message = `Request failed with ${response.status}`;
    try {
      const body = await response.json();
      message = typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail || body.error || body);
    } catch {}
    if (response.status === 401 && typeof window !== 'undefined' && !window.location.pathname.includes('/login')) {
      clearToken();
    }
    throw new Error(message);
  }
  if (response.status === 204) return undefined as T;
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) return response as T;
  return response.json();
}

export function parseWarnings(warningsJson?: string): Array<{ code: string; severity: string; message: string }> {
  if (!warningsJson) return [];
  try { return JSON.parse(warningsJson); } catch { return []; }
}
