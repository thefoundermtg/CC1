export type User = {
  id: string;
  email: string;
  full_name: string;
  role: string;
  pro_affiliation?: string | null;
  ipi_cae_number?: string | null;
  email_verified_at?: string | null;
};

export type Collaborator = {
  id: string;
  email: string;
  legal_name: string;
  stage_name?: string | null;
  creative_role: string;
  split_category: string;
  pro_affiliation?: string | null;
  ipi_cae_number?: string | null;
  publisher_name?: string | null;
  publisher_ipi_cae_number?: string | null;
  payout_reference?: string | null;
  invite_status: string;
  is_work_for_hire: boolean;
  sample_disclosure?: string | null;
};

export type Project = {
  id: string;
  title: string;
  work_type: string;
  alternate_titles?: string | null;
  iswc?: string | null;
  isrc?: string | null;
  release_date?: string | null;
  status: string;
  collaborators: Collaborator[];
};

export type Dashboard = {
  active_projects: number;
  locked_agreements: number;
  pending_signatures: number;
  queued_royalties: string;
  ledger_blocks: number;
  projects_needing_info: number;
  splits_with_warnings: number;
  failed_payouts: number;
  subscription_status: string;
  recent_events: Array<{ action: string; entity_type: string; entity_id: string; created_at: string; metadata: Record<string, unknown> }>;
};

export type SplitParticipant = {
  id: string;
  collaborator_id: string;
  split_category: string;
  contribution_type: string;
  contribution_notes: string;
  percentage: string;
  collaborator: Collaborator;
};

export type SplitProposal = {
  id: string;
  project_id: string;
  input_notes: string;
  ai_summary: string;
  ai_provider: string;
  ai_prompt_version: string;
  confidence_score: number;
  warnings_json: string;
  status: string;
  participants: SplitParticipant[];
};

export type Agreement = {
  id: string;
  project_id: string;
  proposal_id: string;
  template_version: string;
  version: number;
  status: string;
  legal_text: string;
  agreement_hash?: string | null;
  ledger_block_id?: string | null;
  sent_at?: string | null;
  locked_at?: string | null;
};

export type SigningInvite = {
  id: string;
  agreement_id: string;
  collaborator_id: string;
  email: string;
  status: string;
  expires_at: string;
  viewed_at?: string | null;
  used_at?: string | null;
  invite_url?: string | null;
};

export type SigningView = {
  agreement_id: string;
  agreement_status: string;
  project_title: string;
  legal_text: string;
  collaborator_id: string;
  signer_email: string;
  signer_legal_name: string;
  split_percentage?: string | null;
  split_category?: string | null;
  status: string;
};

export type RoyaltyImport = {
  id: string;
  source: string;
  period_start: string;
  period_end: string;
  total_amount: string;
  currency: string;
  status: string;
};

export type Distribution = { id: string; collaborator_id: string; percentage: string; amount: string; currency: string; payout_status: string; batch_id?: string | null };
export type Payout = { id: string; collaborator_id: string; amount: string; currency: string; provider: string; status: string; failure_reason?: string | null };
