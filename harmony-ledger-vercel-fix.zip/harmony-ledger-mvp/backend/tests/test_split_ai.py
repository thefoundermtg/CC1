from app.services.split_ai import SplitAIService


class Collab:
    def __init__(self, id, creative_role):
        self.id = id
        self.creative_role = creative_role


def test_split_ai_totals_100():
    collaborators = [Collab("a", "writer"), Collab("b", "producer"), Collab("c", "artist")]
    result = SplitAIService().generate(
        collaborators,
        "Writer created lyrics and melody; producer made beat; artist performed lead vocal.",
        {"a": "lyrics melody hook primary", "b": "beat production", "c": "lead performance"},
    )
    assert sum(float(item.percentage) for item in result.suggestions) == 100.0
    assert result.confidence_score >= 55
