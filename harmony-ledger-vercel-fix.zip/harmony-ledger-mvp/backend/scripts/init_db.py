from app.db.session import engine
from app.models import Base

Base.metadata.create_all(bind=engine)
print("Local development tables created. Production should use: alembic upgrade head")
