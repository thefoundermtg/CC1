from __future__ import annotations

import uuid
from datetime import datetime
from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def new_uuid() -> str:
    return str(uuid.uuid4())


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(50), default="creator", index=True)
    pro_affiliation: Mapped[str | None] = mapped_column(String(100), nullable=True)
    ipi_cae_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    payout_reference: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    email_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    failed_login_count: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    terms_accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    owned_projects: Mapped[list["Project"]] = relationship(back_populates="owner")
    org_memberships: Mapped[list["OrganizationMembership"]] = relationship("OrganizationMembership", back_populates="user", cascade="all, delete-orphan", foreign_keys="OrganizationMembership.user_id")


class Organization(Base, TimestampMixin):
    __tablename__ = "organizations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    org_type: Mapped[str] = mapped_column(String(50), nullable=False)  # publisher, label, management, admin
    owner_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    subscription_tier: Mapped[str] = mapped_column(String(50), default="free_trial")
    stripe_customer_id: Mapped[str | None] = mapped_column(String(255), nullable=True)

    memberships: Mapped[list["OrganizationMembership"]] = relationship(back_populates="organization", cascade="all, delete-orphan")


class OrganizationMembership(Base, TimestampMixin):
    __tablename__ = "organization_memberships"
    __table_args__ = (UniqueConstraint("organization_id", "user_id", name="uq_org_user"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    organization_id: Mapped[str] = mapped_column(ForeignKey("organizations.id"), index=True, nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    role: Mapped[str] = mapped_column(String(50), default="org_member")
    permissions_json: Mapped[str] = mapped_column(Text, default="[]")
    invited_by_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    organization: Mapped[Organization] = relationship(back_populates="memberships")
    user: Mapped[User] = relationship(back_populates="org_memberships", foreign_keys=[user_id])


class EmailVerificationToken(Base, TimestampMixin):
    __tablename__ = "email_verification_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class PasswordResetToken(Base, TimestampMixin):
    __tablename__ = "password_reset_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class RefreshToken(Base, TimestampMixin):
    __tablename__ = "refresh_tokens"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    replaced_by_token_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)


class Project(Base, TimestampMixin):
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    owner_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    organization_id: Mapped[str | None] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    work_type: Mapped[str] = mapped_column(String(50), default="song")
    alternate_titles: Mapped[str | None] = mapped_column(Text, nullable=True)
    iswc: Mapped[str | None] = mapped_column(String(100), nullable=True)
    isrc: Mapped[str | None] = mapped_column(String(100), nullable=True)
    release_date: Mapped[str | None] = mapped_column(String(20), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="draft")  # draft, pending_review, pending_signatures, fully_signed, locked, archived
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")

    owner: Mapped[User] = relationship(back_populates="owned_projects")
    collaborators: Mapped[list["Collaborator"]] = relationship(back_populates="project", cascade="all, delete-orphan")
    proposals: Mapped[list["SplitProposal"]] = relationship(back_populates="project", cascade="all, delete-orphan")
    agreements: Mapped[list["Agreement"]] = relationship(back_populates="project", cascade="all, delete-orphan")


class Collaborator(Base, TimestampMixin):
    __tablename__ = "collaborators"
    __table_args__ = (UniqueConstraint("project_id", "email", name="uq_project_collaborator_email"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), index=True, nullable=False)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    legal_name: Mapped[str] = mapped_column(String(255), nullable=False)
    stage_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    creative_role: Mapped[str] = mapped_column(String(80), nullable=False)
    split_category: Mapped[str] = mapped_column(String(60), default="composition")
    pro_affiliation: Mapped[str | None] = mapped_column(String(100), nullable=True)
    ipi_cae_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    publisher_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    publisher_ipi_cae_number: Mapped[str | None] = mapped_column(String(100), nullable=True)
    payout_reference: Mapped[str | None] = mapped_column(String(255), nullable=True)
    invite_status: Mapped[str] = mapped_column(String(50), default="pending")
    is_work_for_hire: Mapped[bool] = mapped_column(Boolean, default=False)
    sample_disclosure: Mapped[str | None] = mapped_column(Text, nullable=True)

    project: Mapped[Project] = relationship(back_populates="collaborators")


class SplitProposal(Base, TimestampMixin):
    __tablename__ = "split_proposals"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), index=True, nullable=False)
    created_by_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    input_notes: Mapped[str] = mapped_column(Text, nullable=False)
    ai_summary: Mapped[str] = mapped_column(Text, nullable=False)
    ai_provider: Mapped[str] = mapped_column(String(80), default="deterministic-scoring-v1")
    ai_prompt_version: Mapped[str] = mapped_column(String(80), default="split-ai-v1")
    confidence_score: Mapped[int] = mapped_column(Integer, default=75)
    warnings_json: Mapped[str] = mapped_column(Text, default="[]")
    status: Mapped[str] = mapped_column(String(50), default="draft")  # draft, ready, changes_requested, approved, finalized, superseded, agreement_created
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finalized_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    project: Mapped[Project] = relationship(back_populates="proposals")
    participants: Mapped[list["SplitParticipant"]] = relationship(back_populates="proposal", cascade="all, delete-orphan")


class SplitParticipant(Base, TimestampMixin):
    __tablename__ = "split_participants"
    __table_args__ = (
        UniqueConstraint("proposal_id", "collaborator_id", "split_category", name="uq_proposal_collaborator_category"),
        CheckConstraint("percentage >= 0 AND percentage <= 100", name="ck_split_percentage_range"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    proposal_id: Mapped[str] = mapped_column(ForeignKey("split_proposals.id"), index=True, nullable=False)
    collaborator_id: Mapped[str] = mapped_column(ForeignKey("collaborators.id"), index=True, nullable=False)
    split_category: Mapped[str] = mapped_column(String(60), default="composition")
    contribution_type: Mapped[str] = mapped_column(String(100), nullable=False)
    contribution_notes: Mapped[str] = mapped_column(Text, default="")
    percentage: Mapped[float] = mapped_column(Numeric(5, 2), nullable=False)

    proposal: Mapped[SplitProposal] = relationship(back_populates="participants")
    collaborator: Mapped[Collaborator] = relationship()


class AgreementTemplate(Base, TimestampMixin):
    __tablename__ = "agreement_templates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    template_type: Mapped[str] = mapped_column(String(80), default="split_sheet")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class AgreementTemplateVersion(Base, TimestampMixin):
    __tablename__ = "agreement_template_versions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    template_id: Mapped[str] = mapped_column(ForeignKey("agreement_templates.id"), index=True, nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    change_notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class Agreement(Base, TimestampMixin):
    __tablename__ = "agreements"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), index=True, nullable=False)
    proposal_id: Mapped[str] = mapped_column(ForeignKey("split_proposals.id"), nullable=False)
    template_version: Mapped[str] = mapped_column(String(80), default="harmony-split-sheet-v1")
    version: Mapped[int] = mapped_column(Integer, default=1)
    supersedes_agreement_id: Mapped[str | None] = mapped_column(ForeignKey("agreements.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="draft")  # draft, sent, partially_signed, fully_signed, locked, superseded, declined
    legal_text: Mapped[str] = mapped_column(Text, nullable=False)
    agreement_hash: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    locked_payload_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    ledger_block_id: Mapped[str | None] = mapped_column(ForeignKey("ledger_blocks.id"), nullable=True)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    project: Mapped[Project] = relationship(back_populates="agreements", foreign_keys=[project_id])
    signatures: Mapped[list["Signature"]] = relationship(back_populates="agreement", cascade="all, delete-orphan")
    signing_invites: Mapped[list["SigningInvite"]] = relationship(back_populates="agreement", cascade="all, delete-orphan")
    events: Mapped[list["AgreementEvent"]] = relationship(back_populates="agreement", cascade="all, delete-orphan")
    ledger_block: Mapped["LedgerBlock | None"] = relationship(foreign_keys=[ledger_block_id])


class SigningInvite(Base, TimestampMixin):
    __tablename__ = "signing_invites"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    agreement_id: Mapped[str] = mapped_column(ForeignKey("agreements.id"), index=True, nullable=False)
    collaborator_id: Mapped[str] = mapped_column(ForeignKey("collaborators.id"), index=True, nullable=False)
    email: Mapped[str] = mapped_column(String(255), index=True, nullable=False)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True, nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, sent, viewed, signed, declined, expired
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    viewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decline_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    agreement: Mapped[Agreement] = relationship(back_populates="signing_invites")
    collaborator: Mapped[Collaborator] = relationship()


class AgreementEvent(Base, TimestampMixin):
    __tablename__ = "agreement_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    agreement_id: Mapped[str] = mapped_column(ForeignKey("agreements.id"), index=True, nullable=False)
    actor_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    actor_email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    ip_address: Mapped[str | None] = mapped_column(String(100), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")

    agreement: Mapped[Agreement] = relationship(back_populates="events")


class Signature(Base, TimestampMixin):
    __tablename__ = "signatures"
    __table_args__ = (UniqueConstraint("agreement_id", "signer_email", name="uq_agreement_signer"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    agreement_id: Mapped[str] = mapped_column(ForeignKey("agreements.id"), index=True, nullable=False)
    collaborator_id: Mapped[str | None] = mapped_column(ForeignKey("collaborators.id"), index=True, nullable=True)
    invite_id: Mapped[str | None] = mapped_column(ForeignKey("signing_invites.id"), nullable=True)
    signer_email: Mapped[str] = mapped_column(String(255), nullable=False)
    signer_name: Mapped[str] = mapped_column(String(255), nullable=False)
    consent_text: Mapped[str] = mapped_column(Text, nullable=False)
    agreement_hash_at_signing: Mapped[str] = mapped_column(String(128), nullable=False)
    signature_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    ip_address: Mapped[str | None] = mapped_column(String(100), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(512), nullable=True)
    signed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    agreement: Mapped[Agreement] = relationship(back_populates="signatures")
    collaborator: Mapped[Collaborator | None] = relationship()


class LedgerNetwork(Base, TimestampMixin):
    __tablename__ = "ledger_networks"

    id: Mapped[str] = mapped_column(String(120), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    mode: Mapped[str] = mapped_column(String(80), default="internal_hash_chain")
    public_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class LedgerBlock(Base, TimestampMixin):
    __tablename__ = "ledger_blocks"
    __table_args__ = (UniqueConstraint("network_id", "block_index", name="uq_network_block_index"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    network_id: Mapped[str] = mapped_column(String(120), ForeignKey("ledger_networks.id"), nullable=False, index=True)
    block_index: Mapped[int] = mapped_column(Integer, nullable=False)
    previous_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    payload_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    payload_type: Mapped[str] = mapped_column(String(100), nullable=False)
    payload_ref_id: Mapped[str] = mapped_column(String(36), nullable=False)
    canonical_payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    block_created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    block_hash: Mapped[str] = mapped_column(String(128), nullable=False, unique=True)
    signer_public_key: Mapped[str | None] = mapped_column(Text, nullable=True)
    signature: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)


class RoyaltyStatement(Base, TimestampMixin):
    __tablename__ = "royalty_statements"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    imported_by_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    source: Mapped[str] = mapped_column(String(100), nullable=False)
    original_filename: Mapped[str | None] = mapped_column(String(255), nullable=True)
    storage_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    statement_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    period_start: Mapped[str] = mapped_column(String(20), nullable=False)
    period_end: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="uploaded")


class RoyaltyImport(Base, TimestampMixin):
    __tablename__ = "royalty_imports"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    imported_by_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    statement_id: Mapped[str | None] = mapped_column(ForeignKey("royalty_statements.id"), nullable=True)
    idempotency_key: Mapped[str | None] = mapped_column(String(128), nullable=True, unique=True)
    source: Mapped[str] = mapped_column(String(100), nullable=False)
    period_start: Mapped[str] = mapped_column(String(20), nullable=False)
    period_end: Mapped[str] = mapped_column(String(20), nullable=False)
    total_amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    status: Mapped[str] = mapped_column(String(50), default="processed")


class RoyaltyLineItem(Base, TimestampMixin):
    __tablename__ = "royalty_line_items"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    royalty_import_id: Mapped[str] = mapped_column(ForeignKey("royalty_imports.id"), index=True, nullable=False)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), index=True, nullable=False)
    society_work_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    isrc: Mapped[str | None] = mapped_column(String(100), nullable=True)
    iswc: Mapped[str | None] = mapped_column(String(100), nullable=True)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    gross_amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    match_status: Mapped[str] = mapped_column(String(50), default="matched")


class RoyaltyDistributionBatch(Base, TimestampMixin):
    __tablename__ = "royalty_distribution_batches"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    created_by_user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="draft")  # draft, approved, paid, failed
    total_amount: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class RoyaltyDistribution(Base, TimestampMixin):
    __tablename__ = "royalty_distributions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    line_item_id: Mapped[str] = mapped_column(ForeignKey("royalty_line_items.id"), index=True, nullable=False)
    batch_id: Mapped[str | None] = mapped_column(ForeignKey("royalty_distribution_batches.id"), nullable=True, index=True)
    collaborator_id: Mapped[str] = mapped_column(ForeignKey("collaborators.id"), index=True, nullable=False)
    percentage: Mapped[float] = mapped_column(Numeric(5, 2), nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    payout_status: Mapped[str] = mapped_column(String(50), default="queued")


class PayoutAccount(Base, TimestampMixin):
    __tablename__ = "payout_accounts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    collaborator_id: Mapped[str] = mapped_column(ForeignKey("collaborators.id"), index=True, nullable=False)
    provider: Mapped[str] = mapped_column(String(80), default="stripe_connect")
    provider_account_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="needs_onboarding")
    kyc_status: Mapped[str] = mapped_column(String(50), default="not_started")


class Payout(Base, TimestampMixin):
    __tablename__ = "payouts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    batch_id: Mapped[str | None] = mapped_column(ForeignKey("royalty_distribution_batches.id"), nullable=True)
    distribution_id: Mapped[str | None] = mapped_column(ForeignKey("royalty_distributions.id"), nullable=True)
    collaborator_id: Mapped[str] = mapped_column(ForeignKey("collaborators.id"), index=True, nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    provider: Mapped[str] = mapped_column(String(80), default="mock")
    provider_transfer_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="queued")
    failure_reason: Mapped[str | None] = mapped_column(Text, nullable=True)


class PayoutEvent(Base, TimestampMixin):
    __tablename__ = "payout_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    payout_id: Mapped[str] = mapped_column(ForeignKey("payouts.id"), index=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")


class Subscription(Base, TimestampMixin):
    __tablename__ = "subscriptions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    organization_id: Mapped[str | None] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    plan_code: Mapped[str] = mapped_column(String(80), default="free_trial")
    status: Mapped[str] = mapped_column(String(50), default="trialing")
    stripe_subscription_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    current_period_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class BillingEvent(Base, TimestampMixin):
    __tablename__ = "billing_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    organization_id: Mapped[str | None] = mapped_column(ForeignKey("organizations.id"), nullable=True)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    provider_event_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")


class AuditLog(Base, TimestampMixin):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    actor_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(36), nullable=False)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")
