from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

PUBLIC_REGISTRATION_ROLES = {"creator"}
PRIVILEGED_ROLES = {"publisher_admin", "label_admin", "platform_admin", "org_admin"}


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str | None = None
    token_type: str = "bearer"


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    full_name: str = Field(min_length=2, max_length=255)
    account_type: str = "creator"
    pro_affiliation: str | None = None
    ipi_cae_number: str | None = None
    accept_terms: bool = True

    @field_validator("account_type")
    @classmethod
    def public_roles_only(cls, value: str) -> str:
        value = (value or "creator").strip().lower()
        if value in PRIVILEGED_ROLES:
            raise ValueError("Publisher, label, and admin roles require an organization invite or platform approval")
        return "creator"


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=128)


class EmailIn(BaseModel):
    email: EmailStr


class TokenIn(BaseModel):
    token: str


class PasswordResetIn(BaseModel):
    token: str
    new_password: str = Field(min_length=10, max_length=128)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    email: EmailStr
    full_name: str
    role: str
    pro_affiliation: str | None = None
    ipi_cae_number: str | None = None
    email_verified_at: datetime | None = None


class OrganizationCreateIn(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    org_type: str = Field(default="publisher", max_length=50)


class OrganizationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    org_type: str
    subscription_tier: str


class CollaboratorIn(BaseModel):
    email: EmailStr
    legal_name: str = Field(min_length=2, max_length=255)
    stage_name: str | None = None
    creative_role: str = Field(min_length=2, max_length=80)
    split_category: str = "composition"
    pro_affiliation: str | None = None
    ipi_cae_number: str | None = None
    publisher_name: str | None = None
    publisher_ipi_cae_number: str | None = None
    payout_reference: str | None = None
    is_work_for_hire: bool = False
    sample_disclosure: str | None = None


class CollaboratorUpdateIn(BaseModel):
    email: EmailStr | None = None
    legal_name: str | None = None
    stage_name: str | None = None
    creative_role: str | None = None
    split_category: str | None = None
    pro_affiliation: str | None = None
    ipi_cae_number: str | None = None
    publisher_name: str | None = None
    publisher_ipi_cae_number: str | None = None
    payout_reference: str | None = None
    is_work_for_hire: bool | None = None
    sample_disclosure: str | None = None


class CollaboratorOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    email: EmailStr
    legal_name: str
    stage_name: str | None = None
    creative_role: str
    split_category: str
    pro_affiliation: str | None = None
    ipi_cae_number: str | None = None
    publisher_name: str | None = None
    publisher_ipi_cae_number: str | None = None
    payout_reference: str | None = None
    invite_status: str
    is_work_for_hire: bool
    sample_disclosure: str | None = None


class ProjectCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    work_type: str = "song"
    alternate_titles: str | None = None
    iswc: str | None = None
    isrc: str | None = None
    release_date: str | None = None
    collaborators: list[CollaboratorIn] = Field(default_factory=list)


class ProjectUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=255)
    work_type: str | None = None
    alternate_titles: str | None = None
    iswc: str | None = None
    isrc: str | None = None
    release_date: str | None = None
    status: str | None = None


class ProjectOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    work_type: str
    alternate_titles: str | None = None
    iswc: str | None = None
    isrc: str | None = None
    release_date: str | None = None
    status: str
    collaborators: list[CollaboratorOut] = Field(default_factory=list)


class SplitGenerateIn(BaseModel):
    input_notes: str = Field(min_length=10)
    participant_inputs: dict[str, str] = Field(default_factory=dict)


class SplitWarning(BaseModel):
    code: str
    severity: str
    message: str


class SplitAnalysisOut(BaseModel):
    warnings: list[SplitWarning]
    ready_for_agreement: bool


class SplitParticipantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    collaborator_id: str
    split_category: str
    contribution_type: str
    contribution_notes: str
    percentage: Decimal
    collaborator: CollaboratorOut


class SplitProposalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    input_notes: str
    ai_summary: str
    ai_provider: str
    ai_prompt_version: str
    confidence_score: int
    warnings_json: str
    status: str
    participants: list[SplitParticipantOut] = Field(default_factory=list)


class SplitParticipantOverride(BaseModel):
    collaborator_id: str
    split_category: str = "composition"
    contribution_type: str
    contribution_notes: str = ""
    percentage: Decimal = Field(ge=0, le=100)


class SplitUpdateIn(BaseModel):
    participants: list[SplitParticipantOverride]

    @field_validator("participants")
    @classmethod
    def percentages_total_100_by_category(cls, participants: list[SplitParticipantOverride]):
        totals: dict[str, Decimal] = {}
        for item in participants:
            totals[item.split_category] = totals.get(item.split_category, Decimal("0")) + Decimal(item.percentage)
        bad = {k: v for k, v in totals.items() if abs(v - Decimal("100")) > Decimal("0.01")}
        if bad:
            raise ValueError(f"Split percentages must total exactly 100% per category. Invalid totals: {bad}")
        return participants


class SplitStatusIn(BaseModel):
    reason: str | None = None


class AgreementCreateIn(BaseModel):
    proposal_id: str


class AgreementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    project_id: str
    proposal_id: str
    template_version: str
    version: int
    status: str
    legal_text: str
    agreement_hash: str | None = None
    ledger_block_id: str | None = None
    sent_at: datetime | None = None
    locked_at: datetime | None = None


class SigningInviteOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    agreement_id: str
    collaborator_id: str
    email: EmailStr
    status: str
    expires_at: datetime
    viewed_at: datetime | None = None
    used_at: datetime | None = None
    invite_url: str | None = None


class SignatureIn(BaseModel):
    signer_email: EmailStr
    signer_name: str
    consent_text: str = Field(min_length=20)


class SigningViewOut(BaseModel):
    agreement_id: str
    agreement_status: str
    project_title: str
    legal_text: str
    collaborator_id: str
    signer_email: EmailStr
    signer_legal_name: str
    split_percentage: Decimal | None = None
    split_category: str | None = None
    status: str


class SigningSubmitIn(BaseModel):
    signer_name: str = Field(min_length=2, max_length=255)
    consent_text: str = Field(min_length=20)
    accepted: bool = True


class SigningDeclineIn(BaseModel):
    reason: str = Field(min_length=2, max_length=1000)


class SignatureCertificateOut(BaseModel):
    agreement_id: str
    agreement_hash: str | None
    signatures: list[dict[str, Any]]
    events: list[dict[str, Any]]


class LedgerBlockOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    network_id: str
    block_index: int
    previous_hash: str
    payload_hash: str
    payload_type: str
    payload_ref_id: str
    canonical_payload_json: str
    block_hash: str
    block_created_at: datetime


class LedgerVerifyOut(BaseModel):
    valid: bool
    blocks: int | None = None
    network_id: str | None = None
    failed_block_index: int | None = None
    reason: str | None = None


class RoyaltyLineItemIn(BaseModel):
    project_id: str
    society_work_id: str | None = None
    isrc: str | None = None
    iswc: str | None = None
    description: str
    gross_amount: Decimal = Field(gt=0)
    currency: str = "USD"


class RoyaltyImportIn(BaseModel):
    source: str = "Manual"
    period_start: str
    period_end: str
    currency: str = "USD"
    idempotency_key: str | None = None
    line_items: list[RoyaltyLineItemIn]


class RoyaltyDistributionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    line_item_id: str
    collaborator_id: str
    percentage: Decimal
    amount: Decimal
    currency: str
    payout_status: str
    batch_id: str | None = None


class RoyaltyImportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    source: str
    period_start: str
    period_end: str
    total_amount: Decimal
    currency: str
    status: str


class DistributionBatchOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    status: str
    total_amount: Decimal
    currency: str
    approved_at: datetime | None = None


class PayoutOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    collaborator_id: str
    amount: Decimal
    currency: str
    provider: str
    status: str
    failure_reason: str | None = None


class BillingCheckoutIn(BaseModel):
    plan_code: str = Field(pattern="^(free_trial|pro_creator_49|publisher_label_199|enterprise_custom)$")


class BillingPortalOut(BaseModel):
    url: str
    mode: str


class SubscriptionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    plan_code: str
    status: str
    current_period_end: datetime | None = None


class DashboardOut(BaseModel):
    active_projects: int
    locked_agreements: int
    pending_signatures: int
    queued_royalties: Decimal
    ledger_blocks: int
    projects_needing_info: int
    splits_with_warnings: int
    failed_payouts: int
    subscription_status: str
    recent_events: list[dict[str, Any]]


class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    action: str
    entity_type: str
    entity_id: str
    metadata_json: str
    created_at: datetime
