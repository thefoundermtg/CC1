from __future__ import annotations

from datetime import datetime, timezone
import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.security import get_current_user
from app.db.session import get_db
from app.models import Project, SplitParticipant, SplitProposal, User
from app.schemas import SplitAnalysisOut, SplitGenerateIn, SplitProposalOut, SplitStatusIn, SplitUpdateIn
from app.services.audit import AuditService
from app.services.split_ai import SplitAIService, warnings_json

router = APIRouter(prefix="/projects/{project_id}/splits", tags=["splits"])


def get_project(project_id: str, db: Session, user: User) -> Project:
    project = db.execute(
        select(Project)
        .options(selectinload(Project.collaborators))
        .where(Project.id == project_id, Project.owner_user_id == user.id)
    ).scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


def get_proposal(proposal_id: str, project_id: str, db: Session, user: User) -> SplitProposal:
    get_project(project_id, db, user)
    proposal = db.execute(
        select(SplitProposal)
        .options(selectinload(SplitProposal.participants).selectinload(SplitParticipant.collaborator))
        .where(SplitProposal.id == proposal_id, SplitProposal.project_id == project_id)
    ).scalar_one_or_none()
    if not proposal:
        raise HTTPException(status_code=404, detail="Split proposal not found")
    return proposal


@router.post("/analyze", response_model=SplitAnalysisOut)
def analyze_split(project_id: str, payload: SplitGenerateIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_project(project_id, db, user)
    warnings = SplitAIService().analyze_collaborators(project.collaborators, payload.input_notes, payload.participant_inputs)
    return SplitAnalysisOut(warnings=warnings, ready_for_agreement=not any(w["severity"] == "high" for w in warnings))


@router.post("/generate", response_model=SplitProposalOut, status_code=201)
def generate_split(project_id: str, payload: SplitGenerateIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_project(project_id, db, user)
    result = SplitAIService().generate(project.collaborators, payload.input_notes, payload.participant_inputs)
    proposal = SplitProposal(
        project_id=project.id,
        created_by_user_id=user.id,
        input_notes=payload.input_notes,
        ai_summary=result.summary,
        ai_provider="deterministic-scoring-v1",
        ai_prompt_version="split-ai-v1",
        confidence_score=result.confidence_score,
        warnings_json=warnings_json(result.warnings),
        status="ready",
    )
    project.status = "pending_review"
    db.add(proposal)
    db.flush()
    for suggestion in result.suggestions:
        db.add(SplitParticipant(
            proposal_id=proposal.id,
            collaborator_id=suggestion.collaborator_id,
            split_category=suggestion.split_category,
            contribution_type=suggestion.contribution_type,
            contribution_notes=suggestion.contribution_notes,
            percentage=suggestion.percentage,
        ))
    AuditService(db).log(actor=user, action="split.generated", entity_type="split_proposal", entity_id=proposal.id, metadata={"warnings": result.warnings})
    db.commit()
    return get_proposal(proposal.id, project_id, db, user)


@router.get("", response_model=list[SplitProposalOut])
def list_splits(project_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_project(project_id, db, user)
    return db.execute(
        select(SplitProposal)
        .options(selectinload(SplitProposal.participants).selectinload(SplitParticipant.collaborator))
        .where(SplitProposal.project_id == project_id)
        .order_by(SplitProposal.created_at.desc())
    ).scalars().all()


@router.put("/{proposal_id}", response_model=SplitProposalOut)
def update_split(project_id: str, proposal_id: str, payload: SplitUpdateIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    proposal = get_proposal(proposal_id, project_id, db, user)
    if proposal.status in {"agreement_created", "finalized"}:
        raise HTTPException(status_code=409, detail="Cannot modify a finalized proposal or proposal after agreement creation")
    collaborator_ids = {c.id for c in proposal.project.collaborators}
    for item in payload.participants:
        if item.collaborator_id not in collaborator_ids:
            raise HTTPException(status_code=422, detail=f"Unknown collaborator_id: {item.collaborator_id}")
    for participant in proposal.participants:
        db.delete(participant)
    db.flush()
    for item in payload.participants:
        db.add(SplitParticipant(proposal_id=proposal.id, **item.model_dump()))
    proposal.status = "ready"
    warnings = SplitAIService().analyze_proposal(proposal)
    proposal.warnings_json = warnings_json(warnings)
    AuditService(db).log(actor=user, action="split.updated", entity_type="split_proposal", entity_id=proposal.id, metadata={"participant_count": len(payload.participants)})
    db.commit()
    return get_proposal(proposal.id, project_id, db, user)


@router.post("/{proposal_id}/request-changes", response_model=SplitProposalOut)
def request_changes(project_id: str, proposal_id: str, payload: SplitStatusIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    proposal = get_proposal(proposal_id, project_id, db, user)
    if proposal.status == "agreement_created":
        raise HTTPException(status_code=409, detail="Cannot request changes after agreement creation")
    proposal.status = "changes_requested"
    AuditService(db).log(actor=user, action="split.changes_requested", entity_type="split_proposal", entity_id=proposal.id, metadata={"reason": payload.reason})
    db.commit()
    return get_proposal(proposal.id, project_id, db, user)


@router.post("/{proposal_id}/approve", response_model=SplitProposalOut)
def approve_split(project_id: str, proposal_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    proposal = get_proposal(proposal_id, project_id, db, user)
    warnings = SplitAIService().analyze_proposal(proposal)
    proposal.warnings_json = warnings_json(warnings)
    if any(w["severity"] == "high" for w in warnings):
        raise HTTPException(status_code=422, detail={"message": "Resolve high-severity warnings before approval", "warnings": warnings})
    proposal.status = "approved"
    proposal.approved_at = datetime.now(timezone.utc)
    AuditService(db).log(actor=user, action="split.approved", entity_type="split_proposal", entity_id=proposal.id, metadata={})
    db.commit()
    return get_proposal(proposal.id, project_id, db, user)


@router.post("/{proposal_id}/finalize", response_model=SplitProposalOut)
def finalize_split(project_id: str, proposal_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    proposal = get_proposal(proposal_id, project_id, db, user)
    if proposal.status not in {"approved", "ready"}:
        raise HTTPException(status_code=409, detail="Only ready or approved splits can be finalized")
    proposal.status = "finalized"
    proposal.finalized_at = datetime.now(timezone.utc)
    proposal.project.status = "pending_signatures"
    AuditService(db).log(actor=user, action="split.finalized", entity_type="split_proposal", entity_id=proposal.id, metadata={})
    db.commit()
    return get_proposal(proposal.id, project_id, db, user)
