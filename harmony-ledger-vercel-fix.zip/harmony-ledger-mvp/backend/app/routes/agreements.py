from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.config import get_settings
from app.core.security import get_current_user, hash_token, random_token_urlsafe
from app.db.session import get_db
from app.models import Agreement, AgreementEvent, Project, Signature, SigningInvite, SplitParticipant, SplitProposal, User
from app.schemas import AgreementCreateIn, AgreementOut, LedgerBlockOut, SigningInviteOut, SignatureCertificateOut
from app.services.agreement_exports import simple_text_pdf
from app.services.agreements import AgreementTextService
from app.services.audit import AuditService
from app.services.ledger import LedgerService, canonical_json, sha256
from app.services.notifications import NotificationService
from app.services.split_ai import SplitAIService, warnings_json

router = APIRouter(prefix="/agreements", tags=["agreements"])


def load_agreement(agreement_id: str, db: Session, user: User) -> Agreement:
    agreement = db.execute(
        select(Agreement)
        .options(
            selectinload(Agreement.signatures),
            selectinload(Agreement.signing_invites),
            selectinload(Agreement.events),
            selectinload(Agreement.project).selectinload(Project.collaborators),
            selectinload(Agreement.ledger_block),
        )
        .join(Project, Agreement.project_id == Project.id)
        .where(Agreement.id == agreement_id, Project.owner_user_id == user.id)
    ).scalar_one_or_none()
    if not agreement:
        raise HTTPException(status_code=404, detail="Agreement not found")
    return agreement


def _agreement_lock_payload(agreement: Agreement) -> dict:
    return {
        "agreement_id": agreement.id,
        "project_id": agreement.project_id,
        "proposal_id": agreement.proposal_id,
        "version": agreement.version,
        "template_version": agreement.template_version,
        "legal_text_hash": sha256(agreement.legal_text),
        "signature_hashes": sorted([s.signature_hash for s in agreement.signatures]),
        "signer_emails": sorted([s.signer_email for s in agreement.signatures]),
    }


@router.post("", response_model=AgreementOut, status_code=201)
def create_agreement(payload: AgreementCreateIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    proposal = db.execute(
        select(SplitProposal)
        .options(
            selectinload(SplitProposal.participants).selectinload(SplitParticipant.collaborator),
            selectinload(SplitProposal.project).selectinload(Project.collaborators),
        )
        .where(SplitProposal.id == payload.proposal_id)
    ).scalar_one_or_none()
    if not proposal or proposal.project.owner_user_id != user.id:
        raise HTTPException(status_code=404, detail="Split proposal not found")
    warnings = SplitAIService().analyze_proposal(proposal)
    proposal.warnings_json = warnings_json(warnings)
    if any(w["severity"] == "high" for w in warnings):
        raise HTTPException(status_code=422, detail={"message": "Resolve high-severity split warnings before creating an agreement", "warnings": warnings})
    totals: dict[str, float] = {}
    for participant in proposal.participants:
        totals[participant.split_category] = totals.get(participant.split_category, 0.0) + float(participant.percentage)
    if any(abs(total - 100.0) > 0.01 for total in totals.values()):
        raise HTTPException(status_code=422, detail="Proposal percentages must total 100% per split category")
    version = 1 + len(proposal.project.agreements)
    legal_text = AgreementTextService.build_split_sheet(proposal.project, proposal)
    agreement = Agreement(
        project_id=proposal.project_id,
        proposal_id=proposal.id,
        template_version=AgreementTextService.TEMPLATE_VERSION,
        version=version,
        status="draft",
        legal_text=legal_text,
    )
    proposal.status = "agreement_created"
    proposal.project.status = "pending_signatures"
    db.add(agreement)
    db.flush()
    AuditService(db).agreement_event(agreement_id=agreement.id, event_type="created", actor=user, metadata={"proposal_id": proposal.id})
    AuditService(db).log(actor=user, action="agreement.created", entity_type="agreement", entity_id=agreement.id, metadata={"proposal_id": proposal.id})
    db.commit()
    db.refresh(agreement)
    return agreement


@router.get("", response_model=list[AgreementOut])
def list_agreements(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.execute(
        select(Agreement)
        .join(Project, Agreement.project_id == Project.id)
        .where(Project.owner_user_id == user.id)
        .order_by(Agreement.created_at.desc())
    ).scalars().all()


@router.get("/{agreement_id}", response_model=AgreementOut)
def read_agreement(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return load_agreement(agreement_id, db, user)


@router.post("/{agreement_id}/sign")
def legacy_sign_disabled(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    load_agreement(agreement_id, db, user)
    raise HTTPException(status_code=410, detail="Owner-entered signatures are disabled. Use /agreements/{id}/send-signature-requests and signer invite links.")


@router.post("/{agreement_id}/send-signature-requests", response_model=list[SigningInviteOut])
def send_signature_requests(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    if agreement.status == "locked":
        raise HTTPException(status_code=409, detail="Agreement is already locked")
    settings = get_settings()
    created: list[SigningInviteOut] = []
    expires_at = datetime.now(timezone.utc) + timedelta(days=14)
    for collaborator in agreement.project.collaborators:
        existing = next((invite for invite in agreement.signing_invites if invite.collaborator_id == collaborator.id and invite.status in {"pending", "sent", "viewed"}), None)
        raw_token = random_token_urlsafe(32)
        if existing:
            existing.token_hash = hash_token(raw_token)
            existing.expires_at = expires_at
            existing.status = "sent"
            invite = existing
        else:
            invite = SigningInvite(
                agreement_id=agreement.id,
                collaborator_id=collaborator.id,
                email=collaborator.email.lower(),
                token_hash=hash_token(raw_token),
                expires_at=expires_at,
                status="sent",
            )
            db.add(invite)
            db.flush()
        invite_url = f"{settings.frontend_url}/sign/{raw_token}"
        NotificationService().send_signing_invite(to_email=collaborator.email, invite_url=invite_url, project_title=agreement.project.title)
        created.append(SigningInviteOut.model_validate(invite).model_copy(update={"invite_url": invite_url}))
    agreement.status = "sent"
    agreement.sent_at = datetime.now(timezone.utc)
    AuditService(db).agreement_event(agreement_id=agreement.id, event_type="signature_requests_sent", actor=user, metadata={"count": len(created)})
    AuditService(db).log(actor=user, action="agreement.signature_requests_sent", entity_type="agreement", entity_id=agreement.id, metadata={"count": len(created)})
    db.commit()
    return created


@router.get("/{agreement_id}/signature-certificate", response_model=SignatureCertificateOut)
def signature_certificate(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    signatures = [
        {
            "signer_email": sig.signer_email,
            "signer_name": sig.signer_name,
            "signed_at": sig.signed_at,
            "ip_address": sig.ip_address,
            "user_agent": sig.user_agent,
            "agreement_hash_at_signing": sig.agreement_hash_at_signing,
            "signature_hash": sig.signature_hash,
        }
        for sig in agreement.signatures
    ]
    events = [
        {
            "event_type": event.event_type,
            "actor_email": event.actor_email,
            "created_at": event.created_at,
            "ip_address": event.ip_address,
            "user_agent": event.user_agent,
            "metadata": json.loads(event.metadata_json or "{}"),
        }
        for event in agreement.events
    ]
    return SignatureCertificateOut(agreement_id=agreement.id, agreement_hash=agreement.agreement_hash, signatures=signatures, events=events)


@router.get("/{agreement_id}/pdf")
def agreement_pdf(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    pdf = simple_text_pdf(f"Harmony Ledger Agreement v{agreement.version}", agreement.legal_text)
    return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="harmony-agreement-{agreement.id}.pdf"'})


@router.get("/{agreement_id}/signature-certificate.pdf")
def signature_certificate_pdf(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    cert = signature_certificate(agreement_id, db, user)
    body = json.dumps(cert.model_dump(mode="json"), indent=2)
    pdf = simple_text_pdf(f"Harmony Ledger Signature Certificate {agreement.id}", body)
    return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="signature-certificate-{agreement.id}.pdf"'})


@router.post("/{agreement_id}/lock", response_model=LedgerBlockOut)
def lock_agreement(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    if agreement.status == "locked":
        if not agreement.ledger_block:
            raise HTTPException(status_code=409, detail="Agreement is locked but missing ledger block")
        return agreement.ledger_block
    required_emails = {c.email.lower() for c in agreement.project.collaborators}
    signed_emails = {s.signer_email.lower() for s in agreement.signatures}
    missing = sorted(required_emails - signed_emails)
    if missing:
        raise HTTPException(status_code=409, detail={"message": "Missing required signatures", "missing_signers": missing})

    payload = _agreement_lock_payload(agreement)
    agreement.agreement_hash = sha256(canonical_json(payload))
    agreement.locked_payload_json = canonical_json(payload)
    block = LedgerService(db).append(payload_type="split_agreement", payload_ref_id=agreement.id, payload=payload, actor=user)
    agreement.ledger_block_id = block.id
    agreement.status = "locked"
    agreement.locked_at = datetime.now(timezone.utc)
    agreement.project.status = "locked"
    AuditService(db).agreement_event(agreement_id=agreement.id, event_type="locked_to_ledger", actor=user, metadata={"block_hash": block.block_hash})
    AuditService(db).log(actor=user, action="agreement.locked", entity_type="agreement", entity_id=agreement.id, metadata={"block_id": block.id})
    db.commit()
    db.refresh(block)
    return block


@router.get("/{agreement_id}/ledger-proof")
def ledger_proof(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    if not agreement.ledger_block:
        raise HTTPException(status_code=404, detail="No ledger block exists for this agreement")
    payload = _agreement_lock_payload(agreement)
    return {
        "agreement_id": agreement.id,
        "agreement_hash": agreement.agreement_hash,
        "recomputed_agreement_hash": sha256(canonical_json(payload)),
        "payload_matches_locked_payload": agreement.locked_payload_json == canonical_json(payload),
        "block": LedgerBlockOut.model_validate(agreement.ledger_block).model_dump(mode="json"),
        "chain": LedgerService(db).verify_chain(),
    }


@router.get("/{agreement_id}/verify")
def verify_agreement(agreement_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    agreement = load_agreement(agreement_id, db, user)
    if agreement.status != "locked" or not agreement.agreement_hash or not agreement.ledger_block:
        return {"valid": False, "reason": "Agreement is not locked on the ledger"}
    payload = _agreement_lock_payload(agreement)
    recomputed_agreement_hash = sha256(canonical_json(payload))
    chain = LedgerService(db).verify_chain()
    valid = bool(chain.get("valid")) and recomputed_agreement_hash == agreement.agreement_hash and agreement.ledger_block.payload_hash == sha256(agreement.ledger_block.canonical_payload_json)
    return {
        "valid": valid,
        "agreement_hash": agreement.agreement_hash,
        "recomputed_agreement_hash": recomputed_agreement_hash,
        "ledger_block_hash": agreement.ledger_block.block_hash,
        "chain": chain,
    }
