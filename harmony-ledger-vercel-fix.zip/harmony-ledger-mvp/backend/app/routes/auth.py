from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import (
    create_access_token,
    get_current_user,
    decode_token,
    hash_password,
    hash_token,
    random_token_urlsafe,
    verify_password,
)
from app.db.session import get_db
from app.models import EmailVerificationToken, PasswordResetToken, RefreshToken, Subscription, User
from app.schemas import EmailIn, LoginIn, PasswordResetIn, RegisterIn, TokenIn, TokenOut, UserOut
from app.services.audit import AuditService
from app.services.notifications import NotificationService

router = APIRouter(prefix="/auth", tags=["auth"])


def _set_auth_cookies(response: Response, access_token: str, refresh_token: str | None = None) -> None:
    settings = get_settings()
    response.set_cookie(
        "harmony_access_token",
        access_token,
        httponly=True,
        secure=settings.secure_cookie,
        samesite="lax",
        max_age=settings.access_token_minutes * 60,
    )
    if refresh_token:
        response.set_cookie(
            "harmony_refresh_token",
            refresh_token,
            httponly=True,
            secure=settings.secure_cookie,
            samesite="lax",
            max_age=settings.refresh_token_days * 86400,
        )


def _make_refresh_token(db: Session, user: User) -> str:
    settings = get_settings()
    raw = random_token_urlsafe(48)
    db.add(RefreshToken(user_id=user.id, token_hash=hash_token(raw), expires_at=datetime.now(timezone.utc) + timedelta(days=settings.refresh_token_days)))
    db.flush()
    return raw


def _issue_email_verification(db: Session, user: User) -> str:
    raw = random_token_urlsafe(32)
    db.add(EmailVerificationToken(user_id=user.id, token_hash=hash_token(raw), expires_at=datetime.now(timezone.utc) + timedelta(days=3)))
    db.flush()
    return raw


@router.post("/register", response_model=UserOut, status_code=201)
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    existing = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="Email is already registered")
    now = datetime.now(timezone.utc)
    user = User(
        email=payload.email.lower(),
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        role="creator",
        pro_affiliation=payload.pro_affiliation,
        ipi_cae_number=payload.ipi_cae_number,
        terms_accepted_at=now if payload.accept_terms else None,
    )
    db.add(user)
    db.flush()
    db.add(Subscription(user_id=user.id, plan_code="free_trial", status="trialing", current_period_end=now + timedelta(days=14)))
    token = _issue_email_verification(db, user)
    verify_url = f"{get_settings().frontend_url}/verify-email?token={token}"
    NotificationService().send_email_verification(to_email=user.email, verify_url=verify_url)
    AuditService(db).log(actor=user, action="user.registered", entity_type="user", entity_id=user.id, metadata={"email_verification_sent": True})
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenOut)
def login(payload: LoginIn, response: Response, db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()
    now = datetime.now(timezone.utc)
    locked_until = user.locked_until.replace(tzinfo=timezone.utc) if user and user.locked_until and user.locked_until.tzinfo is None else (user.locked_until if user else None)
    if user and locked_until and locked_until > now:
        raise HTTPException(status_code=423, detail="Account is temporarily locked due to failed login attempts")
    if not user or not verify_password(payload.password, user.password_hash):
        if user:
            user.failed_login_count += 1
            if user.failed_login_count >= 5:
                user.locked_until = now + timedelta(minutes=15)
            db.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password")
    user.failed_login_count = 0
    user.locked_until = None
    user.last_login_at = now
    access_token = create_access_token(user.id, {"role": user.role, "email": user.email})
    refresh_token = _make_refresh_token(db, user)
    AuditService(db).log(actor=user, action="user.logged_in", entity_type="user", entity_id=user.id, metadata={})
    db.commit()
    _set_auth_cookies(response, access_token, refresh_token)
    return TokenOut(access_token=access_token, refresh_token=refresh_token)


@router.post("/refresh", response_model=TokenOut)
def refresh(payload: TokenIn, response: Response, db: Session = Depends(get_db)):
    token_hash = hash_token(payload.token)
    stored = db.execute(select(RefreshToken).where(RefreshToken.token_hash == token_hash)).scalar_one_or_none()
    now = datetime.now(timezone.utc)
    stored_expires_at = stored.expires_at.replace(tzinfo=timezone.utc) if stored and stored.expires_at.tzinfo is None else (stored.expires_at if stored else None)
    if not stored or stored.revoked_at or stored_expires_at <= now:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    user = db.get(User, stored.user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    new_refresh = _make_refresh_token(db, user)
    stored.revoked_at = now
    stored.replaced_by_token_hash = hash_token(new_refresh)
    access_token = create_access_token(user.id, {"role": user.role, "email": user.email})
    db.commit()
    _set_auth_cookies(response, access_token, new_refresh)
    return TokenOut(access_token=access_token, refresh_token=new_refresh)


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("harmony_access_token")
    response.delete_cookie("harmony_refresh_token")
    return {"ok": True}


@router.post("/verify-email")
def verify_email(payload: TokenIn, db: Session = Depends(get_db)):
    token = db.execute(select(EmailVerificationToken).where(EmailVerificationToken.token_hash == hash_token(payload.token))).scalar_one_or_none()
    now = datetime.now(timezone.utc)
    token_expires_at = token.expires_at.replace(tzinfo=timezone.utc) if token and token.expires_at.tzinfo is None else (token.expires_at if token else None)
    if not token or token.used_at or token_expires_at <= now:
        raise HTTPException(status_code=400, detail="Invalid or expired verification token")
    user = db.get(User, token.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.email_verified_at = now
    token.used_at = now
    AuditService(db).log(actor=user, action="user.email_verified", entity_type="user", entity_id=user.id, metadata={})
    db.commit()
    return {"ok": True}


@router.post("/request-email-verification")
def request_email_verification(payload: EmailIn, db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()
    if user and not user.email_verified_at:
        token = _issue_email_verification(db, user)
        NotificationService().send_email_verification(to_email=user.email, verify_url=f"{get_settings().frontend_url}/verify-email?token={token}")
        db.commit()
    return {"ok": True}


@router.post("/password-reset/request")
def request_password_reset(payload: EmailIn, db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == payload.email.lower())).scalar_one_or_none()
    if user:
        raw = random_token_urlsafe(32)
        db.add(PasswordResetToken(user_id=user.id, token_hash=hash_token(raw), expires_at=datetime.now(timezone.utc) + timedelta(hours=2)))
        NotificationService().send_password_reset(to_email=user.email, reset_url=f"{get_settings().frontend_url}/reset-password?token={raw}")
        db.commit()
    return {"ok": True}


@router.post("/password-reset/confirm")
def confirm_password_reset(payload: PasswordResetIn, db: Session = Depends(get_db)):
    token = db.execute(select(PasswordResetToken).where(PasswordResetToken.token_hash == hash_token(payload.token))).scalar_one_or_none()
    now = datetime.now(timezone.utc)
    token_expires_at = token.expires_at.replace(tzinfo=timezone.utc) if token and token.expires_at.tzinfo is None else (token.expires_at if token else None)
    if not token or token.used_at or token_expires_at <= now:
        raise HTTPException(status_code=400, detail="Invalid or expired password reset token")
    user = db.get(User, token.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.password_hash = hash_password(payload.new_password)
    user.failed_login_count = 0
    user.locked_until = None
    token.used_at = now
    AuditService(db).log(actor=user, action="user.password_reset", entity_type="user", entity_id=user.id, metadata={})
    db.commit()
    return {"ok": True}


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user
