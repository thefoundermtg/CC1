from __future__ import annotations

import csv
import io
from datetime import datetime, timezone
from decimal import Decimal
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.db.session import get_db
from app.models import Payout, Project, RoyaltyDistribution, RoyaltyDistributionBatch, RoyaltyImport, RoyaltyLineItem, User
from app.schemas import DistributionBatchOut, PayoutOut, RoyaltyDistributionOut, RoyaltyImportIn, RoyaltyImportOut
from app.services.audit import AuditService
from app.services.royalties import RoyaltyService

router = APIRouter(prefix="/royalties", tags=["royalties"])


def _create_import_from_payload(payload: RoyaltyImportIn, db: Session, user: User) -> RoyaltyImport:
    royalty_service = RoyaltyService(db)
    if payload.idempotency_key:
        existing = db.execute(select(RoyaltyImport).where(RoyaltyImport.idempotency_key == payload.idempotency_key, RoyaltyImport.imported_by_user_id == user.id)).scalar_one_or_none()
        if existing:
            return existing
    total = sum(Decimal(str(item.gross_amount)) for item in payload.line_items)
    royalty_import = RoyaltyImport(
        imported_by_user_id=user.id,
        idempotency_key=payload.idempotency_key,
        source=payload.source,
        period_start=payload.period_start,
        period_end=payload.period_end,
        total_amount=total,
        currency=payload.currency,
        status="processed",
    )
    db.add(royalty_import)
    db.flush()
    for item in payload.line_items:
        royalty_service.ensure_project_access(item.project_id, user)
        line = RoyaltyLineItem(
            royalty_import_id=royalty_import.id,
            project_id=item.project_id,
            society_work_id=item.society_work_id,
            isrc=item.isrc,
            iswc=item.iswc,
            description=item.description,
            gross_amount=item.gross_amount,
            currency=item.currency,
        )
        db.add(line)
        db.flush()
        royalty_service.distribute_line_item(line)
    AuditService(db).log(actor=user, action="royalties.imported", entity_type="royalty_import", entity_id=royalty_import.id, metadata={"line_items": len(payload.line_items)})
    return royalty_import


@router.post("/imports", response_model=RoyaltyImportOut, status_code=201)
def create_manual_import(payload: RoyaltyImportIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    royalty_import = _create_import_from_payload(payload, db, user)
    db.commit()
    db.refresh(royalty_import)
    return royalty_import


@router.post("/imports/csv", response_model=RoyaltyImportOut, status_code=201)
async def import_csv(source: str, period_start: str, period_end: str, file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=422, detail="Only CSV uploads are supported in this MVP adapter")
    content = (await file.read()).decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(content))
    required = {"project_id", "description", "gross_amount"}
    if not required <= set(reader.fieldnames or []):
        raise HTTPException(status_code=422, detail="CSV must include project_id, description, and gross_amount columns")
    items = []
    for row in reader:
        items.append({
            "project_id": row["project_id"],
            "society_work_id": row.get("society_work_id") or None,
            "isrc": row.get("isrc") or None,
            "iswc": row.get("iswc") or None,
            "description": row["description"],
            "gross_amount": row["gross_amount"],
            "currency": row.get("currency") or "USD",
        })
    payload = RoyaltyImportIn(source=source, period_start=period_start, period_end=period_end, line_items=items)
    royalty_import = _create_import_from_payload(payload, db, user)
    db.commit()
    db.refresh(royalty_import)
    return royalty_import


@router.post("/imports/{import_id}/reconcile", response_model=RoyaltyImportOut)
def reconcile_import(import_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    royalty_import = db.execute(select(RoyaltyImport).where(RoyaltyImport.id == import_id, RoyaltyImport.imported_by_user_id == user.id)).scalar_one_or_none()
    if not royalty_import:
        raise HTTPException(status_code=404, detail="Royalty import not found")
    royalty_import.status = "reconciled"
    AuditService(db).log(actor=user, action="royalties.reconciled", entity_type="royalty_import", entity_id=royalty_import.id, metadata={})
    db.commit()
    return royalty_import


@router.get("/imports", response_model=list[RoyaltyImportOut])
def list_imports(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.execute(select(RoyaltyImport).where(RoyaltyImport.imported_by_user_id == user.id).order_by(RoyaltyImport.created_at.desc())).scalars().all()


@router.get("/distributions", response_model=list[RoyaltyDistributionOut])
def list_distributions(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.execute(
        select(RoyaltyDistribution)
        .join(RoyaltyLineItem, RoyaltyDistribution.line_item_id == RoyaltyLineItem.id)
        .join(Project, RoyaltyLineItem.project_id == Project.id)
        .where(Project.owner_user_id == user.id)
        .order_by(RoyaltyDistribution.created_at.desc())
    ).scalars().all()


@router.post("/distribution-batches", response_model=DistributionBatchOut, status_code=201)
def create_distribution_batch(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    batch = RoyaltyService(db).create_distribution_batch(user)
    AuditService(db).log(actor=user, action="royalties.batch_created", entity_type="royalty_distribution_batch", entity_id=batch.id, metadata={})
    db.commit()
    db.refresh(batch)
    return batch


@router.post("/distribution-batches/{batch_id}/approve", response_model=DistributionBatchOut)
def approve_distribution_batch(batch_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    batch = db.execute(select(RoyaltyDistributionBatch).where(RoyaltyDistributionBatch.id == batch_id, RoyaltyDistributionBatch.created_by_user_id == user.id)).scalar_one_or_none()
    if not batch:
        raise HTTPException(status_code=404, detail="Distribution batch not found")
    if batch.status != "draft":
        raise HTTPException(status_code=409, detail="Only draft batches can be approved")
    batch.status = "approved"
    batch.approved_at = datetime.now(timezone.utc)
    RoyaltyService(db).queue_payouts_for_batch(batch)
    AuditService(db).log(actor=user, action="royalties.batch_approved", entity_type="royalty_distribution_batch", entity_id=batch.id, metadata={})
    db.commit()
    return batch


@router.get("/payouts", response_model=list[PayoutOut])
def list_payouts(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.execute(
        select(Payout)
        .join(RoyaltyDistribution, Payout.distribution_id == RoyaltyDistribution.id)
        .join(RoyaltyLineItem, RoyaltyDistribution.line_item_id == RoyaltyLineItem.id)
        .join(Project, RoyaltyLineItem.project_id == Project.id)
        .where(Project.owner_user_id == user.id)
        .order_by(Payout.created_at.desc())
    ).scalars().all()


@router.post("/payouts")
def process_mock_payouts(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    payouts = list_payouts(db, user)
    count = 0
    for payout in payouts:
        if payout.status == "queued":
            payout.status = "paid"
            payout.provider_transfer_id = f"mock_{payout.id}"
            count += 1
    AuditService(db).log(actor=user, action="payouts.processed_mock", entity_type="user", entity_id=user.id, metadata={"paid": count})
    db.commit()
    return {"ok": True, "paid": count}
