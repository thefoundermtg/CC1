from __future__ import annotations

from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import get_current_user
from app.db.session import get_db
from app.models import BillingEvent, Subscription, User
from app.schemas import BillingCheckoutIn, BillingPortalOut, SubscriptionOut
from app.services.audit import AuditService, safe_json

router = APIRouter(prefix="/billing", tags=["billing"])

PLAN_LIMITS = {
    "free_trial": {"projects": 3, "collaborators": 12, "imports": 3, "price": 0},
    "pro_creator_49": {"projects": 50, "collaborators": 250, "imports": 50, "price": 49},
    "publisher_label_199": {"projects": 1000, "collaborators": 10000, "imports": 1000, "price": 199},
    "enterprise_custom": {"projects": -1, "collaborators": -1, "imports": -1, "price": None},
}


@router.get("/subscription", response_model=SubscriptionOut)
def get_subscription(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    subscription = db.execute(select(Subscription).where(Subscription.user_id == user.id).order_by(Subscription.created_at.desc())).scalars().first()
    if not subscription:
        subscription = Subscription(user_id=user.id, plan_code="free_trial", status="trialing", current_period_end=datetime.now(timezone.utc) + timedelta(days=14))
        db.add(subscription)
        db.commit()
        db.refresh(subscription)
    return subscription


@router.get("/limits")
def get_limits(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    subscription = get_subscription(db, user)
    return {"plan_code": subscription.plan_code, "limits": PLAN_LIMITS.get(subscription.plan_code, PLAN_LIMITS["free_trial"])}


@router.post("/checkout", response_model=BillingPortalOut)
def create_checkout(payload: BillingCheckoutIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    settings = get_settings()
    subscription = db.execute(select(Subscription).where(Subscription.user_id == user.id).order_by(Subscription.created_at.desc())).scalars().first()
    if not subscription:
        subscription = Subscription(user_id=user.id)
        db.add(subscription)
        db.flush()
    # Production: replace mock URL with Stripe Checkout session creation using STRIPE_SECRET_KEY.
    subscription.plan_code = payload.plan_code
    subscription.status = "active" if payload.plan_code != "free_trial" else "trialing"
    subscription.current_period_end = datetime.now(timezone.utc) + timedelta(days=30)
    db.add(BillingEvent(user_id=user.id, event_type="checkout.created", metadata_json=safe_json({"plan_code": payload.plan_code, "stripe_configured": bool(settings.stripe_secret_key)})))
    AuditService(db).log(actor=user, action="billing.checkout_created", entity_type="subscription", entity_id=subscription.id, metadata={"plan_code": payload.plan_code})
    db.commit()
    return BillingPortalOut(url=f"{settings.frontend_url}/billing?checkout=mock&plan={payload.plan_code}", mode="mock" if not settings.stripe_secret_key else "stripe_ready")


@router.post("/portal", response_model=BillingPortalOut)
def create_portal(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    settings = get_settings()
    return BillingPortalOut(url=f"{settings.frontend_url}/billing", mode="mock" if not settings.stripe_secret_key else "stripe_ready")


@router.post("/webhooks/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    # Production: verify Stripe-Signature with STRIPE_WEBHOOK_SECRET before processing.
    payload = await request.body()
    db.add(BillingEvent(event_type="stripe.webhook.received", metadata_json=safe_json({"bytes": len(payload), "verified": bool(get_settings().stripe_webhook_secret)})))
    db.commit()
    return {"received": True}
