from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.core.security import get_current_user
from app.db.session import get_db
from app.models import Collaborator, Project, User
from app.schemas import CollaboratorIn, CollaboratorUpdateIn, ProjectCreate, ProjectOut, ProjectUpdate
from app.services.audit import AuditService

router = APIRouter(prefix="/projects", tags=["projects"])


ALLOWED_PROJECT_STATUSES = {"draft", "pending_review", "pending_signatures", "fully_signed", "locked", "archived"}


def get_owned_project(project_id: str, db: Session, user: User) -> Project:
    project = db.execute(
        select(Project)
        .options(selectinload(Project.collaborators))
        .where(Project.id == project_id, Project.owner_user_id == user.id)
    ).scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.post("", response_model=ProjectOut, status_code=201)
def create_project(payload: ProjectCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = Project(
        owner_user_id=user.id,
        title=payload.title,
        work_type=payload.work_type,
        alternate_titles=payload.alternate_titles,
        iswc=payload.iswc,
        isrc=payload.isrc,
        release_date=payload.release_date,
    )
    db.add(project)
    db.flush()
    seen: set[str] = set()
    for collab in payload.collaborators:
        email = collab.email.lower()
        if email in seen:
            raise HTTPException(status_code=422, detail=f"Duplicate collaborator email: {email}")
        seen.add(email)
        db.add(Collaborator(project_id=project.id, **{**collab.model_dump(), "email": email}))
    AuditService(db).log(actor=user, action="project.created", entity_type="project", entity_id=project.id, metadata={"collaborators": len(payload.collaborators)})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="A collaborator email is duplicated on this project") from exc
    db.refresh(project)
    return get_owned_project(project.id, db, user)


@router.get("", response_model=list[ProjectOut])
def list_projects(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    status: str | None = Query(default=None),
    q: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    query = select(Project).options(selectinload(Project.collaborators)).where(Project.owner_user_id == user.id)
    if status:
        query = query.where(Project.status == status)
    if q:
        query = query.where(Project.title.ilike(f"%{q}%"))
    return db.execute(query.order_by(Project.created_at.desc()).limit(limit).offset(offset)).scalars().all()


@router.get("/{project_id}", response_model=ProjectOut)
def read_project(project_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return get_owned_project(project_id, db, user)


@router.patch("/{project_id}", response_model=ProjectOut)
def update_project(project_id: str, payload: ProjectUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    data = payload.model_dump(exclude_unset=True)
    if "status" in data and data["status"] not in ALLOWED_PROJECT_STATUSES:
        raise HTTPException(status_code=422, detail="Invalid project status")
    for key, value in data.items():
        setattr(project, key, value)
    AuditService(db).log(actor=user, action="project.updated", entity_type="project", entity_id=project.id, metadata={"fields": sorted(data.keys())})
    db.commit()
    return get_owned_project(project_id, db, user)


@router.delete("/{project_id}", status_code=204)
def delete_project(project_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    if project.status == "locked":
        raise HTTPException(status_code=409, detail="Locked projects cannot be deleted; archive instead")
    AuditService(db).log(actor=user, action="project.deleted", entity_type="project", entity_id=project.id, metadata={})
    db.delete(project)
    db.commit()
    return None


@router.post("/{project_id}/archive", response_model=ProjectOut)
def archive_project(project_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    project.status = "archived"
    AuditService(db).log(actor=user, action="project.archived", entity_type="project", entity_id=project.id, metadata={})
    db.commit()
    return get_owned_project(project_id, db, user)


@router.post("/{project_id}/collaborators", response_model=ProjectOut)
def add_collaborator(project_id: str, payload: CollaboratorIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    if project.status in {"locked", "pending_signatures", "fully_signed"}:
        raise HTTPException(status_code=409, detail="Create a new agreement version before changing collaborators")
    collaborator = Collaborator(project_id=project.id, **{**payload.model_dump(), "email": payload.email.lower()})
    db.add(collaborator)
    AuditService(db).log(actor=user, action="collaborator.added", entity_type="project", entity_id=project.id, metadata={"email": payload.email.lower()})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Collaborator already exists on this project") from exc
    return get_owned_project(project_id, db, user)


@router.patch("/{project_id}/collaborators/{collaborator_id}", response_model=ProjectOut)
def update_collaborator(project_id: str, collaborator_id: str, payload: CollaboratorUpdateIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    collaborator = next((c for c in project.collaborators if c.id == collaborator_id), None)
    if not collaborator:
        raise HTTPException(status_code=404, detail="Collaborator not found")
    data = payload.model_dump(exclude_unset=True)
    if "email" in data and data["email"]:
        data["email"] = data["email"].lower()
    for key, value in data.items():
        setattr(collaborator, key, value)
    AuditService(db).log(actor=user, action="collaborator.updated", entity_type="collaborator", entity_id=collaborator.id, metadata={"fields": sorted(data.keys())})
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail="Collaborator email conflicts with another collaborator") from exc
    return get_owned_project(project_id, db, user)


@router.delete("/{project_id}/collaborators/{collaborator_id}", response_model=ProjectOut)
def delete_collaborator(project_id: str, collaborator_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    if project.status in {"locked", "pending_signatures", "fully_signed"}:
        raise HTTPException(status_code=409, detail="Create a new agreement version before removing collaborators")
    collaborator = next((c for c in project.collaborators if c.id == collaborator_id), None)
    if not collaborator:
        raise HTTPException(status_code=404, detail="Collaborator not found")
    db.delete(collaborator)
    AuditService(db).log(actor=user, action="collaborator.deleted", entity_type="collaborator", entity_id=collaborator.id, metadata={})
    db.commit()
    return get_owned_project(project_id, db, user)


@router.post("/{project_id}/invite-collaborators")
def invite_collaborators(project_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    project = get_owned_project(project_id, db, user)
    for collaborator in project.collaborators:
        collaborator.invite_status = "invited"
    AuditService(db).log(actor=user, action="collaborators.invited", entity_type="project", entity_id=project.id, metadata={"count": len(project.collaborators)})
    db.commit()
    return {"ok": True, "invited": len(project.collaborators)}
