from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.core.security import hash_token
from app.db.session import get_db
from app.models import Agreement, Collaborator, Signature, SigningInvite, SplitParticipant
from app.schemas import SigningDeclineIn, SigningSubmitIn, SigningViewOut
from app.services.audit import AuditService
from app.services.ledger import canonical_json, sha256

router = APIRouter(prefix="/signing", tags=["signing"])


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else None


def load_invite(token: str, db: Session) -> SigningInvite:
    invite = db.execute(
        select(SigningInvite)
        .options(
            selectinload(SigningInvite.agreement).selectinload(Agreement.project),
            selectinload(SigningInvite.collaborator),
        )
        .where(SigningInvite.token_hash == hash_token(token))
    ).scalar_one_or_none()
    if not invite:
        raise HTTPException(status_code=404, detail="Signing invite not found")
    now = datetime.now(timezone.utc)
    expires_at = invite.expires_at if invite.expires_at.tzinfo else invite.expires_at.replace(tzinfo=timezone.utc)
    if expires_at <= now and invite.status not in {"signed", "declined"}:
        invite.status = "expired"
        db.commit()
        raise HTTPException(status_code=410, detail="Signing invite expired")
    return invite


def _split_for_collaborator(invite: SigningInvite, db: Session) -> SplitParticipant | None:
    return db.execute(
        select(SplitParticipant).where(
            SplitParticipant.proposal_id == invite.agreement.proposal_id,
            SplitParticipant.collaborator_id == invite.collaborator_id,
        )
    ).scalars().first()


@router.get("/invites/{token}", response_model=SigningViewOut)
def view_invite(token: str, request: Request, db: Session = Depends(get_db)):
    invite = load_invite(token, db)
    if invite.status not in {"signed", "declined"}:
        invite.status = "viewed"
        invite.viewed_at = invite.viewed_at or datetime.now(timezone.utc)
        AuditService(db).agreement_event(
            agreement_id=invite.agreement_id,
            event_type="viewed",
            actor_email=invite.email,
            ip_address=_client_ip(request),
            user_agent=request.headers.get("user-agent"),
            metadata={"invite_id": invite.id},
        )
        db.commit()
    split = _split_for_collaborator(invite, db)
    return SigningViewOut(
        agreement_id=invite.agreement_id,
        agreement_status=invite.agreement.status,
        project_title=invite.agreement.project.title,
        legal_text=invite.agreement.legal_text,
        collaborator_id=invite.collaborator_id,
        signer_email=invite.email,
        signer_legal_name=invite.collaborator.legal_name,
        split_percentage=Decimal(str(split.percentage)) if split else None,
        split_category=split.split_category if split else None,
        status=invite.status,
    )


@router.post("/invites/{token}/sign", response_model=SigningViewOut)
def sign_invite(token: str, payload: SigningSubmitIn, request: Request, db: Session = Depends(get_db)):
    invite = load_invite(token, db)
    if invite.status == "signed":
        raise HTTPException(status_code=409, detail="Invite is already signed")
    if invite.status == "declined":
        raise HTTPException(status_code=409, detail="Invite was declined")
    agreement = invite.agreement
    if agreement.status == "locked":
        raise HTTPException(status_code=409, detail="Agreement is already locked")
    if not payload.accepted:
        raise HTTPException(status_code=422, detail="accepted must be true to sign")

    agreement_hash_at_signing = sha256(agreement.legal_text)
    signature_hash = sha256(canonical_json({
        "agreement_id": agreement.id,
        "collaborator_id": invite.collaborator_id,
        "signer_email": invite.email.lower(),
        "signer_name": payload.signer_name,
        "consent_text": payload.consent_text,
        "agreement_hash_at_signing": agreement_hash_at_signing,
        "signed_at": datetime.now(timezone.utc).isoformat(),
    }))
    existing = db.execute(select(Signature).where(Signature.agreement_id == agreement.id, Signature.signer_email == invite.email.lower())).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="This signer has already signed")
    db.add(Signature(
        agreement_id=agreement.id,
        collaborator_id=invite.collaborator_id,
        invite_id=invite.id,
        signer_email=invite.email.lower(),
        signer_name=payload.signer_name,
        consent_text=payload.consent_text,
        agreement_hash_at_signing=agreement_hash_at_signing,
        signature_hash=signature_hash,
        ip_address=_client_ip(request),
        user_agent=request.headers.get("user-agent"),
    ))
    invite.status = "signed"
    invite.used_at = datetime.now(timezone.utc)
    invite.collaborator.invite_status = "accepted"
    required_emails = {c.email.lower() for c in agreement.project.collaborators}
    signed_emails = {sig.signer_email.lower() for sig in agreement.signatures} | {invite.email.lower()}
    agreement.status = "fully_signed" if required_emails <= signed_emails else "partially_signed"
    agreement.project.status = agreement.status
    AuditService(db).agreement_event(
        agreement_id=agreement.id,
        event_type="signed",
        actor_email=invite.email,
        ip_address=_client_ip(request),
        user_agent=request.headers.get("user-agent"),
        metadata={"invite_id": invite.id, "signature_hash": signature_hash},
    )
    db.commit()
    return view_invite(token, request, db)


@router.post("/invites/{token}/decline", response_model=SigningViewOut)
def decline_invite(token: str, payload: SigningDeclineIn, request: Request, db: Session = Depends(get_db)):
    invite = load_invite(token, db)
    if invite.status == "signed":
        raise HTTPException(status_code=409, detail="Invite is already signed")
    invite.status = "declined"
    invite.decline_reason = payload.reason
    invite.used_at = datetime.now(timezone.utc)
    invite.agreement.status = "declined"
    invite.agreement.project.status = "pending_review"
    invite.collaborator.invite_status = "declined"
    AuditService(db).agreement_event(
        agreement_id=invite.agreement_id,
        event_type="declined",
        actor_email=invite.email,
        ip_address=_client_ip(request),
        user_agent=request.headers.get("user-agent"),
        metadata={"reason": payload.reason},
    )
    db.commit()
    return view_invite(token, request, db)
