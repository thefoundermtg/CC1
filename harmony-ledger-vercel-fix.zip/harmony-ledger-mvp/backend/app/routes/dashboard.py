from __future__ import annotations

import json
from decimal import Decimal
from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.db.session import get_db
from app.models import Agreement, AuditLog, LedgerBlock, Project, RoyaltyDistribution, RoyaltyLineItem, SplitProposal, Subscription, User, Payout
from app.schemas import DashboardOut

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardOut)
def dashboard(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    active_projects = db.execute(select(func.count(Project.id)).where(Project.owner_user_id == user.id, Project.status != "archived")).scalar() or 0
    locked_agreements = db.execute(select(func.count(Agreement.id)).join(Project).where(Project.owner_user_id == user.id, Agreement.status == "locked")).scalar() or 0
    pending_signatures = db.execute(select(func.count(Agreement.id)).join(Project).where(Project.owner_user_id == user.id, Agreement.status.in_(["sent", "partially_signed"]))).scalar() or 0
    queued_royalties = db.execute(
        select(func.coalesce(func.sum(RoyaltyDistribution.amount), 0))
        .join(RoyaltyLineItem, RoyaltyDistribution.line_item_id == RoyaltyLineItem.id)
        .join(Project, RoyaltyLineItem.project_id == Project.id)
        .where(Project.owner_user_id == user.id, RoyaltyDistribution.payout_status.in_(["queued", "queued_for_payout"]))
    ).scalar() or Decimal("0.00")
    ledger_blocks = db.execute(select(func.count(LedgerBlock.id))).scalar() or 0
    projects_needing_info = db.execute(select(func.count(Project.id)).where(Project.owner_user_id == user.id, Project.status.in_(["draft", "pending_review"]))).scalar() or 0
    splits_with_warnings = db.execute(
        select(func.count(SplitProposal.id)).join(Project).where(Project.owner_user_id == user.id, SplitProposal.warnings_json != "[]")
    ).scalar() or 0
    failed_payouts = db.execute(
        select(func.count(Payout.id))
        .join(RoyaltyDistribution, Payout.distribution_id == RoyaltyDistribution.id)
        .join(RoyaltyLineItem, RoyaltyDistribution.line_item_id == RoyaltyLineItem.id)
        .join(Project, RoyaltyLineItem.project_id == Project.id)
        .where(Project.owner_user_id == user.id, Payout.status == "failed")
    ).scalar() or 0
    subscription = db.execute(select(Subscription).where(Subscription.user_id == user.id).order_by(Subscription.created_at.desc())).scalars().first()
    recent = db.execute(select(AuditLog).where(AuditLog.actor_user_id == user.id).order_by(AuditLog.created_at.desc()).limit(8)).scalars().all()
    recent_events = [
        {"action": event.action, "entity_type": event.entity_type, "entity_id": event.entity_id, "metadata": json.loads(event.metadata_json or "{}"), "created_at": event.created_at}
        for event in recent
    ]
    return DashboardOut(
        active_projects=active_projects,
        locked_agreements=locked_agreements,
        pending_signatures=pending_signatures,
        queued_royalties=queued_royalties,
        ledger_blocks=ledger_blocks,
        projects_needing_info=projects_needing_info,
        splits_with_warnings=splits_with_warnings,
        failed_payouts=failed_payouts,
        subscription_status=subscription.status if subscription else "none",
        recent_events=recent_events,
    )
