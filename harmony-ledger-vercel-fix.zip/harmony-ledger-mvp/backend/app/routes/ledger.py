from __future__ import annotations

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.db.session import get_db
from app.models import LedgerBlock, User
from app.schemas import LedgerBlockOut, LedgerVerifyOut
from app.services.ledger import LedgerService

router = APIRouter(prefix="/ledger", tags=["ledger"])


@router.get("/blocks", response_model=list[LedgerBlockOut])
def list_blocks(limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.execute(select(LedgerBlock).order_by(LedgerBlock.block_index.desc()).limit(limit).offset(offset)).scalars().all()


@router.get("/blocks/{block_id}", response_model=LedgerBlockOut)
def read_block(block_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    block = db.get(LedgerBlock, block_id)
    if not block:
        raise HTTPException(status_code=404, detail="Ledger block not found")
    return block


@router.get("/verify", response_model=LedgerVerifyOut)
def verify_ledger(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return LedgerService(db).verify_chain()
