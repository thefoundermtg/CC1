from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import Cookie, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
try:
    from jose import JWTError, jwt
except Exception:  # pragma: no cover - dependency fallback for minimal containers.
    class JWTError(Exception):
        pass

    class _JWT:
        @staticmethod
        def _b64(data: bytes) -> str:
            return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")

        @staticmethod
        def _unb64(data: str) -> bytes:
            return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))

        def encode(self, payload: dict[str, Any], secret: str, algorithm: str = "HS256") -> str:
            if algorithm != "HS256":
                raise JWTError("Only HS256 fallback is supported")
            import json
            header = {"alg": "HS256", "typ": "JWT"}
            signing_input = f"{self._b64(json.dumps(header, separators=(",", ":")).encode())}.{self._b64(json.dumps(payload, separators=(",", ":")).encode())}"
            signature = hmac.new(secret.encode(), signing_input.encode(), hashlib.sha256).digest()
            return f"{signing_input}.{self._b64(signature)}"

        def decode(self, token: str, secret: str, algorithms: list[str]) -> dict[str, Any]:
            import json
            try:
                header_b64, payload_b64, signature_b64 = token.split(".")
                signing_input = f"{header_b64}.{payload_b64}"
                expected = self._b64(hmac.new(secret.encode(), signing_input.encode(), hashlib.sha256).digest())
                if not hmac.compare_digest(signature_b64, expected):
                    raise JWTError("Invalid signature")
                payload = json.loads(self._unb64(payload_b64))
                exp = payload.get("exp")
                if exp is not None and int(exp) < int(datetime.now(timezone.utc).timestamp()):
                    raise JWTError("Token expired")
                return payload
            except JWTError:
                raise
            except Exception as exc:
                raise JWTError("Invalid token") from exc

    jwt = _JWT()
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import get_db
from app.models import User

bearer_scheme = HTTPBearer(auto_error=False)

try:  # Preferred production hasher. Requirements include pwdlib[argon2].
    from pwdlib import PasswordHash

    _password_hash = PasswordHash.recommended()
except Exception:  # pragma: no cover - fallback is for minimal dev containers only.
    _password_hash = None


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def random_token_urlsafe(bytes_length: int = 32) -> str:
    return secrets.token_urlsafe(bytes_length)


def _pbkdf2_hash(password: str) -> str:
    salt = os.urandom(16)
    iterations = 390_000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return "pbkdf2_sha256${}${}${}".format(iterations, base64.b64encode(salt).decode(), base64.b64encode(digest).decode())


def _pbkdf2_verify(password: str, encoded: str) -> bool:
    try:
        _, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def hash_password(password: str) -> str:
    if _password_hash is not None:
        return _password_hash.hash(password)
    return _pbkdf2_hash(password)


def verify_password(password: str, hashed: str) -> bool:
    if hashed.startswith("pbkdf2_sha256$"):
        return _pbkdf2_verify(password, hashed)
    if _password_hash is not None:
        try:
            return _password_hash.verify(password, hashed)
        except Exception:
            return False
    return False


def password_needs_rehash(hashed: str) -> bool:
    if _password_hash is None:
        return False
    try:
        return _password_hash.verify_and_update("__never_user_password__", hashed)[1] is not None
    except Exception:
        return False


def create_access_token(subject: str, extra_claims: dict[str, Any] | None = None) -> str:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=settings.access_token_minutes)).timestamp()),
        "typ": "access",
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_token(token: str, expected_type: str = "access") -> dict[str, Any]:
    settings = get_settings()
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except JWTError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Could not validate credentials") from exc
    if payload.get("typ", "access") != expected_type:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Wrong token type")
    return payload


def get_current_user(
    db: Session = Depends(get_db),
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    harmony_access_token: str | None = Cookie(default=None),
) -> User:
    token = credentials.credentials if credentials else harmony_access_token
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    payload = decode_token(token, "access")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Could not validate credentials")
    user = db.get(User, user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Could not validate credentials")
    return user


def require_roles(*roles: str):
    def dependency(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return current_user
    return dependency
