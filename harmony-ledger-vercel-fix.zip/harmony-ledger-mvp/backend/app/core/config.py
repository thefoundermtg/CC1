from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Harmony Ledger API"
    environment: str = Field(default="development", alias="ENVIRONMENT")
    database_url: str = Field(default="sqlite:///./harmony_ledger.db", alias="DATABASE_URL")
    jwt_secret: str = Field(default="change-me-in-production", alias="JWT_SECRET")
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = Field(default=60, alias="ACCESS_TOKEN_MINUTES")
    refresh_token_days: int = Field(default=30, alias="REFRESH_TOKEN_DAYS")
    cors_origins: str = Field(default="http://localhost:3000", alias="CORS_ORIGINS")
    frontend_url: str = Field(default="http://localhost:3000", alias="FRONTEND_URL")
    ledger_network_id: str = Field(default="harmony-ledger-permissioned-devnet", alias="LEDGER_NETWORK_ID")
    ledger_network_name: str = Field(default="Harmony Ledger DevNet", alias="LEDGER_NETWORK_NAME")
    royalty_import_mode: str = Field(default="manual", alias="ROYALTY_IMPORT_MODE")
    auto_create_tables: bool = Field(default=False, alias="AUTO_CREATE_TABLES")
    rate_limit_per_minute: int = Field(default=120, alias="RATE_LIMIT_PER_MINUTE")
    secure_cookie: bool = Field(default=False, alias="SECURE_COOKIE")
    stripe_secret_key: str | None = Field(default=None, alias="STRIPE_SECRET_KEY")
    stripe_webhook_secret: str | None = Field(default=None, alias="STRIPE_WEBHOOK_SECRET")

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
