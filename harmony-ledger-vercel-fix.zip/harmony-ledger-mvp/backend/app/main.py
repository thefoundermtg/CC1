from __future__ import annotations

import time
import uuid
from collections import defaultdict, deque
from typing import Deque

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette import status

from app.core.config import get_settings
from app.db.session import engine
from app.models import Base
from app.routes import agreements, auth, billing, dashboard, ledger, projects, royalties, signing, splits

settings = get_settings()

if settings.auto_create_tables:
    # Local-only convenience. Production must run Alembic migrations instead.
    Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="AI-assisted split sheet management with authenticated signer flow, tamper-evident ledger records, billing scaffolding, and royalty distribution tracking.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_rate_bucket: dict[str, Deque[float]] = defaultdict(deque)


@app.middleware("http")
async def request_context_and_security_headers(request: Request, call_next):
    request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
    client_ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "unknown").split(",")[0].strip()
    now = time.monotonic()
    bucket = _rate_bucket[client_ip]
    while bucket and now - bucket[0] > 60:
        bucket.popleft()
    if len(bucket) >= settings.rate_limit_per_minute:
        return JSONResponse(status_code=429, content={"error": {"code": "rate_limited", "message": "Too many requests", "request_id": request_id}})
    bucket.append(now)
    response = await call_next(request)
    response.headers["x-request-id"] = request_id
    response.headers["x-content-type-options"] = "nosniff"
    response.headers["x-frame-options"] = "DENY"
    response.headers["referrer-policy"] = "no-referrer"
    response.headers["permissions-policy"] = "camera=(), microphone=(), geolocation=()"
    if settings.environment == "production":
        response.headers["strict-transport-security"] = "max-age=31536000; includeSubDomains"
    return response


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"error": {"code": "validation_error", "message": "Request validation failed", "details": exc.errors(), "request_id": request.headers.get("x-request-id")}},
    )


@app.get("/api/health", tags=["health"])
def health():
    return {"service": settings.app_name, "status": "online", "environment": settings.environment, "version": "1.0.0"}


@app.get("/api/ready", tags=["health"])
def ready():
    return {"service": settings.app_name, "ready": True, "database": "configured"}


@app.get("/api/version", tags=["health"])
def version():
    return {"service": settings.app_name, "version": "1.0.0"}


app.include_router(auth.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(splits.router, prefix="/api")
app.include_router(agreements.router, prefix="/api")
app.include_router(signing.router, prefix="/api")
app.include_router(ledger.router, prefix="/api")
app.include_router(royalties.router, prefix="/api")
app.include_router(billing.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
