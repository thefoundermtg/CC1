from __future__ import annotations

from decimal import Decimal
from app.models import Project, SplitProposal


class AgreementTextService:
    TEMPLATE_VERSION = "harmony-split-sheet-v1"

    @staticmethod
    def build_split_sheet(project: Project, proposal: SplitProposal) -> str:
        rows = []
        for participant in proposal.participants:
            collaborator = participant.collaborator
            rows.append(
                f"- {collaborator.legal_name}"
                f"{f' p/k/a {collaborator.stage_name}' if collaborator.stage_name else ''} <{collaborator.email}> | "
                f"Category: {participant.split_category} | Role: {participant.contribution_type} | "
                f"IPI/CAE: {collaborator.ipi_cae_number or 'Not provided'} | "
                f"PRO: {collaborator.pro_affiliation or 'Not provided'} | "
                f"Publisher: {collaborator.publisher_name or 'Not provided'} | "
                f"Publisher IPI/CAE: {collaborator.publisher_ipi_cae_number or 'Not provided'} | "
                f"Work-for-hire: {'Yes' if collaborator.is_work_for_hire else 'No'} | "
                f"Split: {Decimal(participant.percentage):.2f}% | Notes: {participant.contribution_notes or 'None'}"
            )
        split_rows = "\n".join(rows)
        alternate_titles = project.alternate_titles or "None listed"
        warnings = proposal.warnings_json or "[]"
        return f"""HARMONY LEDGER SPLIT SHEET AGREEMENT
Template Version: {AgreementTextService.TEMPLATE_VERSION}

IMPORTANT PLATFORM NOTICE
Harmony Ledger is an AI-assisted split sheet workflow and tamper-evident records platform. Harmony Ledger is not a law firm, does not provide legal advice, and does not decide ownership. The collaborators remain responsible for verifying facts, percentages, authority, publisher information, samples/interpolations, work-for-hire terms, administration rights, and any governing legal requirements before signing.

WORK INFORMATION
Song/Work Title: {project.title}
Work Type: {project.work_type}
Alternate Titles: {alternate_titles}
ISWC: {project.iswc or 'Pending'}
ISRC: {project.isrc or 'Pending'}
Release Date: {project.release_date or 'Pending'}

COLLABORATOR SPLITS
{split_rows}

AI-ASSIST DISCLOSURE
AI Provider/Mode: {proposal.ai_provider}
Prompt/Rules Version: {proposal.ai_prompt_version}
Confidence Score: {proposal.confidence_score}%
Review Warnings: {warnings}

CREATOR ACKNOWLEDGMENTS
1. Each listed collaborator confirms that the stated split percentage accurately reflects their agreed share for the listed work and category.
2. Each collaborator confirms that their legal name, email, PRO affiliation, IPI/CAE number, publisher information, sample/interpolation disclosures, work-for-hire status, and payout reference are accurate to the best of their knowledge.
3. The parties understand that writer share, publisher share, master ownership, producer points, neighboring rights, mechanical royalties, performance royalties, and sync income may be different rights. This template records only the categories expressly listed above.
4. Any sample, interpolation, beat lease, union, label, publisher, administration, work-for-hire, or prior contract issue should be reviewed by qualified counsel before reliance.
5. Each signer consents to electronic records and signatures, and authorizes Harmony Ledger to capture the signer name, email, IP address, user agent, timestamp, agreement hash, and signature hash for the signature certificate and audit trail.
6. After all required collaborators sign, Harmony Ledger may lock a canonical payload hash to its permissioned tamper-evident ledger. A future edit requires a new agreement version and new signatures.
7. Disputes, corrections, or ownership changes should be handled through a superseding written agreement or other legally binding correction process.

E-SIGN CONSENT
By signing through a unique Harmony Ledger signing link, each signer agrees that their electronic signature has the same effect as a handwritten signature for this agreement, subject to applicable law.
""".strip()
