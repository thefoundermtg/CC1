from __future__ import annotations

import logging

logger = logging.getLogger("harmony_ledger.notifications")


class NotificationService:
    """Email/provider boundary.

    Production integrations should implement this interface with SES, SendGrid, Postmark, or Mailgun.
    The MVP logs links so local development and automated tests do not depend on external providers.
    """

    def send_signing_invite(self, *, to_email: str, invite_url: str, project_title: str) -> None:
        logger.info("Signing invite for %s on %s: %s", to_email, project_title, invite_url)

    def send_email_verification(self, *, to_email: str, verify_url: str) -> None:
        logger.info("Email verification for %s: %s", to_email, verify_url)

    def send_password_reset(self, *, to_email: str, reset_url: str) -> None:
        logger.info("Password reset for %s: %s", to_email, reset_url)
