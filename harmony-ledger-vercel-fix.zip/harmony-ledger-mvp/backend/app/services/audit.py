from __future__ import annotations

import json
from typing import Any
from sqlalchemy.orm import Session

from app.models import AgreementEvent, AuditLog, User


def safe_json(value: Any) -> str:
    return json.dumps(value or {}, sort_keys=True, default=str)


class AuditService:
    def __init__(self, db: Session):
        self.db = db

    def log(self, *, actor: User | None, action: str, entity_type: str, entity_id: str, metadata: dict[str, Any] | None = None) -> AuditLog:
        entry = AuditLog(
            actor_user_id=actor.id if actor else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            metadata_json=safe_json(metadata),
        )
        self.db.add(entry)
        self.db.flush()
        return entry

    def agreement_event(
        self,
        *,
        agreement_id: str,
        event_type: str,
        actor: User | None = None,
        actor_email: str | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> AgreementEvent:
        event = AgreementEvent(
            agreement_id=agreement_id,
            actor_user_id=actor.id if actor else None,
            actor_email=actor_email,
            event_type=event_type,
            ip_address=ip_address,
            user_agent=user_agent,
            metadata_json=safe_json(metadata),
        )
        self.db.add(event)
        self.db.flush()
        return event
