from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP
from sqlalchemy import select
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.models import Agreement, Payout, Project, RoyaltyDistribution, RoyaltyDistributionBatch, RoyaltyLineItem, SplitParticipant, User


class RoyaltyService:
    def __init__(self, db: Session):
        self.db = db

    def ensure_project_access(self, project_id: str, user: User) -> Project:
        project = self.db.execute(select(Project).where(Project.id == project_id, Project.owner_user_id == user.id)).scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail=f"Project not found or not accessible: {project_id}")
        return project

    def distribute_line_item(self, line_item: RoyaltyLineItem) -> list[RoyaltyDistribution]:
        agreement = self.db.execute(
            select(Agreement)
            .where(Agreement.project_id == line_item.project_id, Agreement.status == "locked")
            .order_by(Agreement.version.desc())
        ).scalars().first()
        if not agreement:
            raise HTTPException(status_code=409, detail="Project has no locked agreement. Lock a split sheet before distributing royalties.")

        participants = self.db.execute(
            select(SplitParticipant).where(SplitParticipant.proposal_id == agreement.proposal_id)
        ).scalars().all()
        total = Decimal(str(line_item.gross_amount))
        created: list[RoyaltyDistribution] = []
        running = Decimal("0.00")
        for idx, participant in enumerate(participants):
            if idx == len(participants) - 1:
                amount = total - running
            else:
                amount = (total * Decimal(str(participant.percentage)) / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                running += amount
            dist = RoyaltyDistribution(
                line_item_id=line_item.id,
                collaborator_id=participant.collaborator_id,
                percentage=participant.percentage,
                amount=amount,
                currency=line_item.currency,
                payout_status="queued",
            )
            self.db.add(dist)
            created.append(dist)
        self.db.flush()
        return created

    def create_distribution_batch(self, user: User) -> RoyaltyDistributionBatch:
        queued = self.db.execute(
            select(RoyaltyDistribution)
            .join(RoyaltyLineItem, RoyaltyDistribution.line_item_id == RoyaltyLineItem.id)
            .join(Project, RoyaltyLineItem.project_id == Project.id)
            .where(Project.owner_user_id == user.id, RoyaltyDistribution.payout_status == "queued", RoyaltyDistribution.batch_id.is_(None))
        ).scalars().all()
        if not queued:
            raise HTTPException(status_code=409, detail="No queued distributions are available for batching")
        total = sum(Decimal(str(item.amount)) for item in queued)
        currency = queued[0].currency
        batch = RoyaltyDistributionBatch(created_by_user_id=user.id, total_amount=total, currency=currency, status="draft")
        self.db.add(batch)
        self.db.flush()
        for item in queued:
            item.batch_id = batch.id
        self.db.flush()
        return batch

    def queue_payouts_for_batch(self, batch: RoyaltyDistributionBatch) -> list[Payout]:
        distributions = self.db.execute(select(RoyaltyDistribution).where(RoyaltyDistribution.batch_id == batch.id)).scalars().all()
        payouts: list[Payout] = []
        for distribution in distributions:
            payout = Payout(
                batch_id=batch.id,
                distribution_id=distribution.id,
                collaborator_id=distribution.collaborator_id,
                amount=distribution.amount,
                currency=distribution.currency,
                provider="mock",
                status="queued",
            )
            distribution.payout_status = "queued_for_payout"
            self.db.add(payout)
            payouts.append(payout)
        self.db.flush()
        return payouts
