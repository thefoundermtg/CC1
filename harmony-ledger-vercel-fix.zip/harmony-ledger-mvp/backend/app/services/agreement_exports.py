from __future__ import annotations

from datetime import datetime, timezone


def _escape_pdf_text(value: str) -> str:
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)").replace("\r", "")


def simple_text_pdf(title: str, body: str) -> bytes:
    """Generate a minimal, dependency-free PDF for MVP exports.

    This is intentionally plain. In production, replace it with a branded renderer such as WeasyPrint,
    Prince, or ReportLab and store the immutable export in object storage.
    """
    lines = [title, f"Generated: {datetime.now(timezone.utc).isoformat()}", ""] + body.splitlines()
    content_lines = []
    y = 760
    for raw in lines[:48]:
        line = _escape_pdf_text(raw[:105])
        content_lines.append(f"BT /F1 9 Tf 50 {y} Td ({line}) Tj ET")
        y -= 14
        if y < 48:
            break
    stream = "\n".join(content_lines).encode("latin-1", errors="replace")
    objects = [
        b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj",
        b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj",
        b"3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj",
        b"4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj",
        b"5 0 obj << /Length " + str(len(stream)).encode() + b" >> stream\n" + stream + b"\nendstream endobj",
    ]
    pdf = bytearray(b"%PDF-1.4\n")
    offsets = [0]
    for obj in objects:
        offsets.append(len(pdf))
        pdf.extend(obj + b"\n")
    xref = len(pdf)
    pdf.extend(f"xref\n0 {len(objects)+1}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010d} 00000 n \n".encode())
    pdf.extend(f"trailer << /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode())
    return bytes(pdf)
