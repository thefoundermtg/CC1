from __future__ import annotations

import json
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from app.models import Collaborator, SplitParticipant, SplitProposal


ROLE_WEIGHTS = {
    "writer": 1.2,
    "songwriter": 1.2,
    "composer": 1.2,
    "producer": 1.1,
    "artist": 0.9,
    "publisher": 0.35,
    "engineer": 0.45,
    "mixer": 0.45,
    "mastering": 0.25,
}
KEYWORD_WEIGHTS = {
    "lyrics": 1.0,
    "melody": 1.0,
    "topline": 1.0,
    "beat": 0.85,
    "production": 0.85,
    "arrangement": 0.55,
    "hook": 0.75,
    "verse": 0.55,
    "composition": 1.0,
    "publishing": 0.35,
    "mix": 0.25,
    "master": 0.20,
    "sample": -0.1,
}


@dataclass
class SuggestedSplit:
    collaborator_id: str
    split_category: str
    contribution_type: str
    contribution_notes: str
    percentage: Decimal


@dataclass
class SplitAIResult:
    summary: str
    confidence_score: int
    warnings: list[dict[str, str]]
    suggestions: list[SuggestedSplit]


class SplitAIService:
    """Transparent AI-assist boundary.

    The current production-safe MVP uses deterministic contribution scoring plus explicit warnings.
    A real LLM adapter can be added behind this interface without letting AI silently decide ownership.
    """

    def generate(self, collaborators: list[Collaborator], project_notes: str, participant_notes: dict[str, str]) -> SplitAIResult:
        if not collaborators:
            raise ValueError("At least one collaborator is required before generating splits.")

        raw_scores: dict[str, float] = {}
        for collaborator in collaborators:
            role = collaborator.creative_role.lower().strip()
            notes = participant_notes.get(collaborator.id, "").lower()
            score = ROLE_WEIGHTS.get(role, 0.75)
            for keyword, weight in KEYWORD_WEIGHTS.items():
                if keyword in notes:
                    score += weight
            if "primary" in notes or "lead" in notes:
                score += 0.8
            if "minor" in notes or "small" in notes:
                score *= 0.65
            raw_scores[collaborator.id] = max(score, 0.1)

        total_score = sum(raw_scores.values())
        suggestions: list[SuggestedSplit] = []
        running_total = Decimal("0.00")
        for idx, collaborator in enumerate(collaborators):
            if idx == len(collaborators) - 1:
                percentage = Decimal("100.00") - running_total
            else:
                percentage = Decimal(str(raw_scores[collaborator.id] / total_score * 100)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                running_total += percentage
            notes = participant_notes.get(collaborator.id, "")
            suggestions.append(
                SuggestedSplit(
                    collaborator_id=collaborator.id,
                    split_category=getattr(collaborator, "split_category", "composition") or "composition",
                    contribution_type=collaborator.creative_role,
                    contribution_notes=notes,
                    percentage=percentage,
                )
            )

        warnings = self.analyze_collaborators(collaborators, project_notes, participant_notes)
        confidence = self._confidence_score(project_notes, participant_notes, collaborators, warnings)
        summary = (
            "Harmony Ledger generated a proposed split using collaborator roles, contribution notes, and "
            "explainable keyword scoring. This is an assistive draft only; collaborators must review, edit, "
            "approve, and sign before any agreement is locked."
        )
        return SplitAIResult(summary=summary, confidence_score=confidence, warnings=warnings, suggestions=suggestions)

    def analyze_collaborators(self, collaborators: list[Collaborator], project_notes: str, participant_notes: dict[str, str]) -> list[dict[str, str]]:
        warnings: list[dict[str, str]] = []
        if len(project_notes.strip()) < 80:
            warnings.append({"code": "thin_session_notes", "severity": "medium", "message": "Session summary is thin. Add who created lyrics, melody, production, hook, verses, samples, and ownership expectations."})
        for collaborator in collaborators:
            notes = participant_notes.get(collaborator.id, "").strip()
            name = getattr(collaborator, "legal_name", collaborator.id)
            if not notes:
                warnings.append({"code": "missing_contribution_notes", "severity": "high", "message": f"{name} has no contribution notes."})
            if not getattr(collaborator, "ipi_cae_number", None):
                warnings.append({"code": "missing_ipi_cae", "severity": "medium", "message": f"{name} is missing IPI/CAE."})
            if not getattr(collaborator, "pro_affiliation", None):
                warnings.append({"code": "missing_pro", "severity": "medium", "message": f"{name} is missing PRO affiliation."})
            if "sample" in notes.lower() or getattr(collaborator, "sample_disclosure", None):
                warnings.append({"code": "sample_disclosure", "severity": "high", "message": f"{name} references sample/interpolation issues. Clearances should be reviewed before release."})
            if collaborator.creative_role.lower() == "publisher" and getattr(collaborator, "split_category", "composition") == "composition":
                warnings.append({"code": "publisher_writer_mix", "severity": "high", "message": f"{name} is marked as publisher in a composition split. Confirm writer share vs publisher share."})
        if any(getattr(c, "is_work_for_hire", False) for c in collaborators):
            warnings.append({"code": "work_for_hire", "severity": "high", "message": "One or more collaborators are marked work-for-hire. Attach/review the underlying contract before signing."})
        return warnings

    def analyze_proposal(self, proposal: SplitProposal) -> list[dict[str, str]]:
        warnings: list[dict[str, str]] = []
        totals: dict[str, Decimal] = {}
        participants: list[SplitParticipant] = list(proposal.participants)
        for participant in participants:
            category = participant.split_category or "composition"
            totals[category] = totals.get(category, Decimal("0")) + Decimal(str(participant.percentage))
            collaborator = participant.collaborator
            if not getattr(collaborator, "ipi_cae_number", None):
                warnings.append({"code": "missing_ipi_cae", "severity": "medium", "message": f"{name} is missing IPI/CAE."})
            if not getattr(collaborator, "pro_affiliation", None):
                warnings.append({"code": "missing_pro", "severity": "medium", "message": f"{name} is missing PRO affiliation."})
        for category, total in totals.items():
            if abs(total - Decimal("100")) > Decimal("0.01"):
                warnings.append({"code": "split_total_not_100", "severity": "high", "message": f"{category} split totals {total}%, not 100%."})
        if not participants:
            warnings.append({"code": "no_participants", "severity": "high", "message": "No split participants exist."})
        return warnings

    def _confidence_score(self, project_notes: str, participant_notes: dict[str, str], collaborators: list[Collaborator], warnings: list[dict[str, str]]) -> int:
        score = 55
        if len(project_notes) >= 80:
            score += 10
        populated = sum(1 for c in collaborators if participant_notes.get(c.id, "").strip())
        score += int((populated / max(len(collaborators), 1)) * 25)
        if any("primary" in note.lower() or "minor" in note.lower() for note in participant_notes.values()):
            score += 5
        score -= 8 * sum(1 for warning in warnings if warning.get("severity") == "high")
        score -= 3 * sum(1 for warning in warnings if warning.get("severity") == "medium")
        return max(30, min(score, 95))


def warnings_json(warnings: list[dict[str, str]]) -> str:
    return json.dumps(warnings, sort_keys=True)
