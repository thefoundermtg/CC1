from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models import LedgerBlock, LedgerNetwork, User


def canonical_json(payload: dict) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def block_body_for_hash(block: LedgerBlock | dict) -> dict:
    if isinstance(block, dict):
        return {
            "network_id": block["network_id"],
            "block_index": block["block_index"],
            "previous_hash": block["previous_hash"],
            "payload_hash": block["payload_hash"],
            "payload_type": block["payload_type"],
            "payload_ref_id": block["payload_ref_id"],
            "canonical_payload_json": block["canonical_payload_json"],
            "block_created_at": block["block_created_at"],
            "created_by_user_id": block["created_by_user_id"],
        }
    return {
        "network_id": block.network_id,
        "block_index": block.block_index,
        "previous_hash": block.previous_hash,
        "payload_hash": block.payload_hash,
        "payload_type": block.payload_type,
        "payload_ref_id": block.payload_ref_id,
        "canonical_payload_json": block.canonical_payload_json,
        "block_created_at": block.block_created_at.isoformat(),
        "created_by_user_id": block.created_by_user_id,
    }


class LedgerService:
    """Append-only permissioned tamper-evident ledger.

    The MVP ledger stores a canonical JSON payload and a recomputable block hash. This is production-safe
    terminology for the current implementation: it is tamper-evident and can later be anchored to Fabric,
    Quorum, FireFly, or another permissioned blockchain without changing the agreement domain model.
    """

    def __init__(self, db: Session):
        self.db = db
        self.settings = get_settings()

    def ensure_network(self) -> LedgerNetwork:
        network = self.db.get(LedgerNetwork, self.settings.ledger_network_id)
        if not network:
            network = LedgerNetwork(
                id=self.settings.ledger_network_id,
                name=self.settings.ledger_network_name,
                mode="internal_hash_chain",
            )
            self.db.add(network)
            self.db.flush()
        return network

    def append(self, *, payload_type: str, payload_ref_id: str, payload: dict, actor: User) -> LedgerBlock:
        self.ensure_network()
        latest = self.db.execute(
            select(LedgerBlock).where(LedgerBlock.network_id == self.settings.ledger_network_id).order_by(LedgerBlock.block_index.desc())
        ).scalars().first()
        previous_hash = latest.block_hash if latest else "GENESIS"
        next_index = (latest.block_index + 1) if latest else 1
        canonical_payload = canonical_json(payload)
        payload_hash = sha256(canonical_payload)
        block_created_at = datetime.now(timezone.utc).replace(tzinfo=None)
        block_body = {
            "network_id": self.settings.ledger_network_id,
            "block_index": next_index,
            "previous_hash": previous_hash,
            "payload_hash": payload_hash,
            "payload_type": payload_type,
            "payload_ref_id": payload_ref_id,
            "canonical_payload_json": canonical_payload,
            "block_created_at": block_created_at.isoformat(),
            "created_by_user_id": actor.id,
        }
        block_hash = sha256(canonical_json(block_body))
        block = LedgerBlock(
            network_id=self.settings.ledger_network_id,
            block_index=next_index,
            previous_hash=previous_hash,
            payload_hash=payload_hash,
            payload_type=payload_type,
            payload_ref_id=payload_ref_id,
            canonical_payload_json=canonical_payload,
            block_created_at=block_created_at,
            block_hash=block_hash,
            created_by_user_id=actor.id,
        )
        self.db.add(block)
        self.db.flush()
        return block

    def verify_chain(self) -> dict:
        blocks = self.db.execute(
            select(LedgerBlock).where(LedgerBlock.network_id == self.settings.ledger_network_id).order_by(LedgerBlock.block_index.asc())
        ).scalars().all()
        previous = "GENESIS"
        expected_index = 1
        for block in blocks:
            if block.block_index != expected_index:
                return {"valid": False, "failed_block_index": block.block_index, "reason": "block_index gap"}
            if block.previous_hash != previous:
                return {"valid": False, "failed_block_index": block.block_index, "reason": "previous_hash mismatch"}
            recomputed_payload_hash = sha256(block.canonical_payload_json)
            if recomputed_payload_hash != block.payload_hash:
                return {"valid": False, "failed_block_index": block.block_index, "reason": "payload_hash mismatch"}
            recomputed_block_hash = sha256(canonical_json(block_body_for_hash(block)))
            if recomputed_block_hash != block.block_hash:
                return {"valid": False, "failed_block_index": block.block_index, "reason": "block_hash mismatch"}
            previous = block.block_hash
            expected_index += 1
        return {"valid": True, "blocks": len(blocks), "network_id": self.settings.ledger_network_id}

    def count(self) -> int:
        return int(self.db.execute(select(func.count(LedgerBlock.id))).scalar() or 0)
